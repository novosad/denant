<?php

class TicketsSectionDataManagerController extends ResourceDataManagerController {
}