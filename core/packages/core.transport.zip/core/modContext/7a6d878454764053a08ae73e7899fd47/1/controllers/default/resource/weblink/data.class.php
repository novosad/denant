<?php
/**
 * @package modx
 * @subpackage manager.controllers
 */
class WebLinkDataManagerController extends ResourceDataManagerController {}
