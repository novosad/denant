<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'd1c9743b5d068b0540a21a9e874cdb2d',
      'native_key' => 'core',
      'filename' => 'modNamespace/0031268b5391acdaafc8ae76f0dc9967.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modWorkspace',
      'guid' => '31350f9fab822e7ce6fde81824aff717',
      'native_key' => 1,
      'filename' => 'modWorkspace/dca95c0571757ce3c95187169d5c3859.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modTransportProvider',
      'guid' => 'f6bd3a636942d6c41167f741435e8de8',
      'native_key' => 1,
      'filename' => 'modTransportProvider/56d243c25fced77905e9eb9bb5b6492e.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '59a0a1e3162bebceaa0686df6fb228f8',
      'native_key' => 'topnav',
      'filename' => 'modMenu/dfbc3e528119d7cc36e8f085384a9a8c.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'be3438e71e09cd5f352a76af58bd6a57',
      'native_key' => 'usernav',
      'filename' => 'modMenu/460245129b5ff09362f385a2da970098.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'd7d8936ed37b08c25512b41fb56ff607',
      'native_key' => 1,
      'filename' => 'modContentType/8de796a90e0b8f52e4ba599d411d05ee.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'f280de3a15e46777778dca5debb6b821',
      'native_key' => 2,
      'filename' => 'modContentType/8607d751d486c8846eb0535af7b106ca.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '097d2c1707593625848841ee0c3f970e',
      'native_key' => 3,
      'filename' => 'modContentType/f71a8deabe9ce6cd4343db62011cbb14.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'fd77c22e936df8c847275045a17cb3df',
      'native_key' => 4,
      'filename' => 'modContentType/d537271eb9a77577c5cb53c311b39bfb.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '0d12c096f642544d9887171807e297a6',
      'native_key' => 5,
      'filename' => 'modContentType/33e96ffc152edc2dcf90cb046c499cb1.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'd25cf3ebbdaf307cafe83d68059a06ea',
      'native_key' => 6,
      'filename' => 'modContentType/682ad5efceb605d1ad19727774d1aaa8.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '882d677334b1950d02b26754b7751dc3',
      'native_key' => 7,
      'filename' => 'modContentType/ff37bc7d79ce1a9cfabb647b6a067184.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '97dd90fef7d56573bf1e4786baf5f8a3',
      'native_key' => 8,
      'filename' => 'modContentType/119b90ed6393a2e8c9959b064e6c1865.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'e76db681942713ceebdd5a0168f35aec',
      'native_key' => NULL,
      'filename' => 'modClassMap/5dbab5aff58b856dc4fc591b556e621c.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '2e3af1c0cea376b51d82254c999ea87d',
      'native_key' => NULL,
      'filename' => 'modClassMap/d0c2aac42451ca70346ef8e876fbd13b.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '87d3bda6ff26630d17d90a3fd4f1cca2',
      'native_key' => NULL,
      'filename' => 'modClassMap/bfdee66fc6a65f7af4601e4b58cecd9a.vehicle',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '41c7a844745d3e9d9e14041786350e23',
      'native_key' => NULL,
      'filename' => 'modClassMap/b3c965a7d79d4a8cc23a20196299a5a0.vehicle',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '02b12b55d0d8d4065d4c7ba7d1380a42',
      'native_key' => NULL,
      'filename' => 'modClassMap/f859cc0e13b3af775c767b84ed08f9e3.vehicle',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '1b905a8092a562bc3ca9d77b1c227fe8',
      'native_key' => NULL,
      'filename' => 'modClassMap/a7e7c7818476d187dcc1faccd8b25c40.vehicle',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '90934da88f993f178f830e5d8a16958e',
      'native_key' => NULL,
      'filename' => 'modClassMap/94d0574c0f8c420b83c362ab55335412.vehicle',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '78f959993e1c4df186fab39452259216',
      'native_key' => NULL,
      'filename' => 'modClassMap/84fa4340c0ca7b689d7839aa50b57ab5.vehicle',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'beea173137f02e6124378a12c9e2e3cb',
      'native_key' => NULL,
      'filename' => 'modClassMap/39a86cf6516615cdf1f9b9b2ae438974.vehicle',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9c2b5456be1551c01d166551b6519ec6',
      'native_key' => 'OnPluginEventBeforeSave',
      'filename' => 'modEvent/63d77d1de939d9a849639e9dccb16866.vehicle',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1353078cec7996b58f08251ac1a8df83',
      'native_key' => 'OnPluginEventSave',
      'filename' => 'modEvent/2de83546c1cb5b7d700b611fb6961e14.vehicle',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e9c15b7c0efb66165463bf285674c83d',
      'native_key' => 'OnPluginEventBeforeRemove',
      'filename' => 'modEvent/84a921bb13b65038daf5d45a78e747e4.vehicle',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4e6d231f9010bec2891d427a1777fd52',
      'native_key' => 'OnPluginEventRemove',
      'filename' => 'modEvent/7e663e515caacde1776cc6a760e635ed.vehicle',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ea45347621ed8cacff5a3de90c7c60fa',
      'native_key' => 'OnResourceGroupSave',
      'filename' => 'modEvent/83cd7d17b96dd4437492b96611f1db8a.vehicle',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '71487f874a85843ce71efb6e3bb87b3e',
      'native_key' => 'OnResourceGroupBeforeSave',
      'filename' => 'modEvent/051a7994227488085b7f9803f3dc3984.vehicle',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a07387e153ec59dedf3239ce2611b7cc',
      'native_key' => 'OnResourceGroupRemove',
      'filename' => 'modEvent/3e4d7d879a0763beadfeb639086d03b8.vehicle',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f8fbb62461fdf13adac29fe86f6fde7e',
      'native_key' => 'OnResourceGroupBeforeRemove',
      'filename' => 'modEvent/d5fbb083522e00227c16ecafe2135089.vehicle',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0e0831831132dd30e63e0d216ed000c3',
      'native_key' => 'OnSnippetBeforeSave',
      'filename' => 'modEvent/21851d20d6e3eee979fc9879241b150c.vehicle',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1216f0e5c79d2d1f17563e0be6e9d210',
      'native_key' => 'OnSnippetSave',
      'filename' => 'modEvent/c8abb507eeca773e7ed92bbe7ffee08a.vehicle',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a02ee92ecaa80aeacce94b0de0c69088',
      'native_key' => 'OnSnippetBeforeRemove',
      'filename' => 'modEvent/b47f956ac3615af7756e908be64ef5c5.vehicle',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'aec9ce2a611fb0e91636625270831c4b',
      'native_key' => 'OnSnippetRemove',
      'filename' => 'modEvent/86b78d50935fa0fa810f4e417432e610.vehicle',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8cc6158a54959fb16a36db2bb10eda0a',
      'native_key' => 'OnSnipFormPrerender',
      'filename' => 'modEvent/f837c3ab052d99d02589b073f79d9e24.vehicle',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b802bd3de2a77697e41b235cadc7883c',
      'native_key' => 'OnSnipFormRender',
      'filename' => 'modEvent/aa1a63437a1cdd962414d2dfb00f1237.vehicle',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6d7d9e06f667619be05d48ac127bd2f1',
      'native_key' => 'OnBeforeSnipFormSave',
      'filename' => 'modEvent/49b96daf41c4f31400d08b517c333076.vehicle',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '56a7a59abad5d6357c0697e0b29deb69',
      'native_key' => 'OnSnipFormSave',
      'filename' => 'modEvent/5d3c28eaade0d65ab45485b560a4f942.vehicle',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8eec8dcde9239b02b9a30772851784c2',
      'native_key' => 'OnBeforeSnipFormDelete',
      'filename' => 'modEvent/6077d4bec3f8d376d0c5aebb057dcde9.vehicle',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6ff30aa8c11d80964d4feb65e623e1e7',
      'native_key' => 'OnSnipFormDelete',
      'filename' => 'modEvent/8495862a4d6fa5926d7c6908d9c5217a.vehicle',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0640cff569640deb77c1f818da37fe20',
      'native_key' => 'OnTemplateBeforeSave',
      'filename' => 'modEvent/a84e18ef6a084791a0882a1a127aaac4.vehicle',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3cd4626524f6a69310198b0e27a54f12',
      'native_key' => 'OnTemplateSave',
      'filename' => 'modEvent/ccc31134cbd8a1a625b7f93e888e96c0.vehicle',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '144c136f70754eba0417e5d43c59c7ae',
      'native_key' => 'OnTemplateBeforeRemove',
      'filename' => 'modEvent/3c65baf716b660e12e59eafd8a5edab1.vehicle',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a3b9aebba696559e7eb5607a782824a5',
      'native_key' => 'OnTemplateRemove',
      'filename' => 'modEvent/e8e1d2665ae82b2d3660036cae798ecc.vehicle',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '57a575f3baabfec589b0ea0d3b57ba2e',
      'native_key' => 'OnTempFormPrerender',
      'filename' => 'modEvent/dd270c00489d46a4c74c0cd7d7c4241c.vehicle',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '74e3530183fb4440e5e8e89ec67ec7dd',
      'native_key' => 'OnTempFormRender',
      'filename' => 'modEvent/76c05e210d8b6ed6ed21289c2c343a0e.vehicle',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3684140fde42ab8740ae98cccc2a61b0',
      'native_key' => 'OnBeforeTempFormSave',
      'filename' => 'modEvent/ba552207db90c907fa674dd536ada22f.vehicle',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6caf3a55bcb2310b626238429b30f8a9',
      'native_key' => 'OnTempFormSave',
      'filename' => 'modEvent/39bf5b97d35121e4b0f75fbde05f24b9.vehicle',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7d9356bdf8c7ce095dce728ccd5fc7f4',
      'native_key' => 'OnBeforeTempFormDelete',
      'filename' => 'modEvent/5a649e847bcd2e85811c7ef326a7030c.vehicle',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9cc191433624fecc248aedf37df57e19',
      'native_key' => 'OnTempFormDelete',
      'filename' => 'modEvent/01d70ef534c7d8e796089eed65bfb2cc.vehicle',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '686c0ff74ea6ddc7eb939fb01a5c12d2',
      'native_key' => 'OnTemplateVarBeforeSave',
      'filename' => 'modEvent/9246b30ade4037f655fee825ef5fbe48.vehicle',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '868aebdb183796eb2ccbb65075ef9724',
      'native_key' => 'OnTemplateVarSave',
      'filename' => 'modEvent/7ff70ed54684abfd2094b4295ce7c7d6.vehicle',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a1b7badeef170010c1c2a4d2084edb30',
      'native_key' => 'OnTemplateVarBeforeRemove',
      'filename' => 'modEvent/48319403e1e0cccc3284fd69e057eeb7.vehicle',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6fde687e8dbfdd1fc03d1b0805c333f6',
      'native_key' => 'OnTemplateVarRemove',
      'filename' => 'modEvent/4c7d7c28706005df30c1542716aec02f.vehicle',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2ab6cd412283cb7343a4b967fe24ec1b',
      'native_key' => 'OnTVFormPrerender',
      'filename' => 'modEvent/6e900cf454c64072de19d66ea00c4f24.vehicle',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a0d246d7c07e0374c2b5b56f0bf8fac6',
      'native_key' => 'OnTVFormRender',
      'filename' => 'modEvent/eabaf8ac3fbd011ffb92415f6bfc07f2.vehicle',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ed8ac67604fb45f2f096ca1289f78469',
      'native_key' => 'OnBeforeTVFormSave',
      'filename' => 'modEvent/df5fa101551a7f899e67bab125088aaf.vehicle',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b90e7f45a8d9a22ca93608e038b12924',
      'native_key' => 'OnTVFormSave',
      'filename' => 'modEvent/6a89e733d4d2bb1e1c0cb67422448af6.vehicle',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '55c933d5dc754908882a2f8d21593197',
      'native_key' => 'OnBeforeTVFormDelete',
      'filename' => 'modEvent/3f4fdce36fb31d547819fee82285265a.vehicle',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0907715092187eff4828a8c4ccdaa7bf',
      'native_key' => 'OnTVFormDelete',
      'filename' => 'modEvent/a9e9acb3828e7e2093a5bf728d0dcb44.vehicle',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '576b87225e0581e1b23ff51f19d4f9e2',
      'native_key' => 'OnTVInputRenderList',
      'filename' => 'modEvent/e093982e4bd38baf4ca89a99c357857a.vehicle',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '75967262476ab2864bb32ec3103f42a0',
      'native_key' => 'OnTVInputPropertiesList',
      'filename' => 'modEvent/9084fdfe95866a49aed57a2e324ef410.vehicle',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ad9b29788ce1f907dc2dc500f1fd2187',
      'native_key' => 'OnTVOutputRenderList',
      'filename' => 'modEvent/553928474890ee058698dca31af8fe86.vehicle',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6cabb2844e8e94f866e3fbee9c339216',
      'native_key' => 'OnTVOutputRenderPropertiesList',
      'filename' => 'modEvent/237f90bfd6042285c2f56872c35f8452.vehicle',
    ),
    64 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bf2a3e332164dbd8573a408b1ed32c19',
      'native_key' => 'OnUserGroupBeforeSave',
      'filename' => 'modEvent/1abc84abb1658651d72b2f18e8eae0c7.vehicle',
    ),
    65 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ab88dd26bb4eddfbbb19757eaa1b7565',
      'native_key' => 'OnUserGroupSave',
      'filename' => 'modEvent/792e2fc565e27cb9a808e65ec71ab58b.vehicle',
    ),
    66 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a2c3697e77e626b5e713c05f118ce60c',
      'native_key' => 'OnUserGroupBeforeRemove',
      'filename' => 'modEvent/14a28bac1ac08fd8a45bd77209feac9f.vehicle',
    ),
    67 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '335192de1fe2ffaa1360e1d34f5a4215',
      'native_key' => 'OnUserGroupRemove',
      'filename' => 'modEvent/a776f70bde734b328ddc07817df05673.vehicle',
    ),
    68 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '95ca16f6843725704423ec212c20ad4c',
      'native_key' => 'OnBeforeUserGroupFormSave',
      'filename' => 'modEvent/93621fbd6280073f5f7c761a74287806.vehicle',
    ),
    69 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9d503073374ce81cd5b52379774fa6a5',
      'native_key' => 'OnUserGroupFormSave',
      'filename' => 'modEvent/4f66e16d63b3dc31ec90cb8548c65154.vehicle',
    ),
    70 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2a972156717badf135341b3478858910',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/cffba7e2b6da945fc7ea64b79a43f8de.vehicle',
    ),
    71 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '59f7502a73a8f1264af32de93dc92fb8',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/13a9f3e67d5efea6585cdfe4a88a4bb3.vehicle',
    ),
    72 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b6f34f54424b962d8ff17862e8f8e01f',
      'native_key' => 'OnDocFormPrerender',
      'filename' => 'modEvent/81f28357cfcb2d818be1683c28a18595.vehicle',
    ),
    73 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '12a48d4aad3218c4fd081a00ac175c19',
      'native_key' => 'OnDocFormRender',
      'filename' => 'modEvent/4a85adc8304c5a0922ee779a90426cc0.vehicle',
    ),
    74 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '78f47cfc5c3d0af249ac187e3369fc98',
      'native_key' => 'OnBeforeDocFormSave',
      'filename' => 'modEvent/e4405d6d7adee807c8c8dfe00030879a.vehicle',
    ),
    75 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1b5eadc8aedb0011765fe6ee27b06bbf',
      'native_key' => 'OnDocFormSave',
      'filename' => 'modEvent/8a70340fc81d68469eef04adae635e02.vehicle',
    ),
    76 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bda3e4dff85d47860650921b45f9757c',
      'native_key' => 'OnBeforeDocFormDelete',
      'filename' => 'modEvent/d832beebdb34f10fa604143a0312304c.vehicle',
    ),
    77 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7140d965e3718beeca1f03602eecbb70',
      'native_key' => 'OnDocFormDelete',
      'filename' => 'modEvent/51ce14f0fdfc18d4e278ece43f489749.vehicle',
    ),
    78 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd09a38891b815a036ba250c576ccdca3',
      'native_key' => 'OnDocPublished',
      'filename' => 'modEvent/a5e99d80e698505d562aaf4edc66e55a.vehicle',
    ),
    79 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dde25d6182cc3732d0633edf94acae49',
      'native_key' => 'OnDocUnPublished',
      'filename' => 'modEvent/0f48dc591612fa38e01f294bd2086ba7.vehicle',
    ),
    80 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3448a78752412579ab5eccff9363de99',
      'native_key' => 'OnBeforeEmptyTrash',
      'filename' => 'modEvent/b9ae82913eeb70e784f1cc895fa8d786.vehicle',
    ),
    81 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '185646df527530c716fa94f7c077485b',
      'native_key' => 'OnEmptyTrash',
      'filename' => 'modEvent/f7e559849863b53df4caf8535c12a04f.vehicle',
    ),
    82 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'da936447c08aa0fbee9bd3216298085e',
      'native_key' => 'OnResourceTVFormPrerender',
      'filename' => 'modEvent/1c8abe8749b8b7e8005aa5ff0b441578.vehicle',
    ),
    83 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3dd33f0faed62d2d383bd07a283205bd',
      'native_key' => 'OnResourceTVFormRender',
      'filename' => 'modEvent/9d12048d36a07a0c213cc258a7ee70d8.vehicle',
    ),
    84 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'be9be4ca97247218ee074c23db32fc9f',
      'native_key' => 'OnResourceAutoPublish',
      'filename' => 'modEvent/de26fcf0775378fec37c98f2a594f89a.vehicle',
    ),
    85 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '74bb448e5e21c6a811ae0e629786e168',
      'native_key' => 'OnResourceDelete',
      'filename' => 'modEvent/2adabc9f376ac6aef22edb1d59b69322.vehicle',
    ),
    86 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ef1f7bb02f5a9d04693f16f156fd55d1',
      'native_key' => 'OnResourceUndelete',
      'filename' => 'modEvent/04e119b4b155c2910d83bc01734c9a4a.vehicle',
    ),
    87 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '574ac48fbb10033bf31721d4af942ceb',
      'native_key' => 'OnResourceBeforeSort',
      'filename' => 'modEvent/0a2bc6d096ea91db8ab25080251809d9.vehicle',
    ),
    88 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '64051cee3d923183acef8dd6a8c1101f',
      'native_key' => 'OnResourceSort',
      'filename' => 'modEvent/a55acc0e30154630c4b4e3f1a9be208a.vehicle',
    ),
    89 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '89577d8532a0bd469d38377d16d4ea32',
      'native_key' => 'OnResourceDuplicate',
      'filename' => 'modEvent/bf5e939cde4618f50ce56837f009b745.vehicle',
    ),
    90 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bf96f6ba073d92fd63ea4aafbf919e88',
      'native_key' => 'OnResourceToolbarLoad',
      'filename' => 'modEvent/9386c8efd2e7944bd4e1076612bd84a5.vehicle',
    ),
    91 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0fa7098d0124ac2428ae1ae0dde2142c',
      'native_key' => 'OnResourceRemoveFromResourceGroup',
      'filename' => 'modEvent/f1ca25ded421f012c4884c6ff380dcc2.vehicle',
    ),
    92 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '41763ee1935c9a66483a346c0efa4525',
      'native_key' => 'OnResourceAddToResourceGroup',
      'filename' => 'modEvent/019d1fabcaeb2cbf6dbf73c6535c6260.vehicle',
    ),
    93 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4721d98ad6927a6653e3489064951769',
      'native_key' => 'OnRichTextEditorRegister',
      'filename' => 'modEvent/d6534d5c9e5a74cae25116e7ed48164d.vehicle',
    ),
    94 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8530fffbc5ad75b32674dddb95e4273f',
      'native_key' => 'OnRichTextEditorInit',
      'filename' => 'modEvent/b72421d5c2302a8800f51c485d6eb87d.vehicle',
    ),
    95 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e9aa02a87e70615a8974e3a5a59b6566',
      'native_key' => 'OnRichTextBrowserInit',
      'filename' => 'modEvent/88b6c93b1034a30b5f22d3dd5b55e823.vehicle',
    ),
    96 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '94fb4b39c9d4046d0532c392fedbaf48',
      'native_key' => 'OnWebLogin',
      'filename' => 'modEvent/db86f63c2b52db64e51bc4d9c4be5c42.vehicle',
    ),
    97 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2f5e513c24d5675928468fb02dcf3f39',
      'native_key' => 'OnBeforeWebLogout',
      'filename' => 'modEvent/e1e4bf9662d186a2e909a83dd44e245d.vehicle',
    ),
    98 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c7500ef3c013fa9585d409efd2edad4a',
      'native_key' => 'OnWebLogout',
      'filename' => 'modEvent/e9d4f2b9f00336cd7c7238092aefd619.vehicle',
    ),
    99 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '02733e57daba35b224d9df1e938adf5d',
      'native_key' => 'OnManagerLogin',
      'filename' => 'modEvent/397fd304367728272b37b12dbdb09a0b.vehicle',
    ),
    100 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3de976963c44184b2f6ca9e0c5a5e106',
      'native_key' => 'OnBeforeManagerLogout',
      'filename' => 'modEvent/87c965a04ae38a40e3339da45e3efc7c.vehicle',
    ),
    101 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '776296aaa4f0ca42c809771eeaf6eb94',
      'native_key' => 'OnManagerLogout',
      'filename' => 'modEvent/1fed8c11dbddc41e81d46a786dbed5e5.vehicle',
    ),
    102 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8a9dee63b1749f2b02e21c93bcb3d85a',
      'native_key' => 'OnBeforeWebLogin',
      'filename' => 'modEvent/aa27eeacc871759ccde29c3e16ac4163.vehicle',
    ),
    103 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a009d4850176cd8a247411667f1fc515',
      'native_key' => 'OnWebAuthentication',
      'filename' => 'modEvent/80bf79de838d31a68e0a3565267fbbfe.vehicle',
    ),
    104 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e53f40321e4e4de0e375fe40d6d3dbf8',
      'native_key' => 'OnBeforeManagerLogin',
      'filename' => 'modEvent/41c1875f30fc1ea9b3a160155ce3df2b.vehicle',
    ),
    105 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ed1d96aa8b5abc5927571e0a8e7bec1d',
      'native_key' => 'OnManagerAuthentication',
      'filename' => 'modEvent/50fda670f0ce58f135a515cbdf07c219.vehicle',
    ),
    106 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '513ae8607744ebf4a876c10c26a7414f',
      'native_key' => 'OnManagerLoginFormRender',
      'filename' => 'modEvent/b0bbd6baed3a2d5b4fdf2d5ced24d3ef.vehicle',
    ),
    107 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '11bbf343b5c24c1b7f6117729ec4224e',
      'native_key' => 'OnManagerLoginFormPrerender',
      'filename' => 'modEvent/72bd136a2e797d0592e9ee5b8b01cba0.vehicle',
    ),
    108 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5a9a78483109a92ce0aed004733af71b',
      'native_key' => 'OnPageUnauthorized',
      'filename' => 'modEvent/5c91c6ecf7a2b74b978e5581097ed593.vehicle',
    ),
    109 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2762e7f3c37f10d6944aaf555ea4787f',
      'native_key' => 'OnUserFormPrerender',
      'filename' => 'modEvent/bb4e21d4b45c9a9d672b05bd5ce0d0e9.vehicle',
    ),
    110 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '58a395c7047cadf246e2a57ee6f7b0cc',
      'native_key' => 'OnUserFormRender',
      'filename' => 'modEvent/6ee2e13f2f7c1785ab408779fb947d09.vehicle',
    ),
    111 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '287bd5e7989afadc387d2eed132853d8',
      'native_key' => 'OnBeforeUserFormSave',
      'filename' => 'modEvent/6dd452b15a4d903e9a220390ba5fb5e3.vehicle',
    ),
    112 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2921943a315dde8c3582c101ab176fe8',
      'native_key' => 'OnUserFormSave',
      'filename' => 'modEvent/650599dd5f3898e7d7b62d160ba6ad1c.vehicle',
    ),
    113 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '473dc8b2574dbf999846ccdef4d25e1a',
      'native_key' => 'OnBeforeUserFormDelete',
      'filename' => 'modEvent/56a263d1cdf49af2f4c49da3b67717a0.vehicle',
    ),
    114 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '512a985b913ff02e507d49c2caf23c86',
      'native_key' => 'OnUserFormDelete',
      'filename' => 'modEvent/3e74e0c028c95031d9cda5a8d5dc2413.vehicle',
    ),
    115 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0f0f4529451929eecaff8b284e6af3c5',
      'native_key' => 'OnUserNotFound',
      'filename' => 'modEvent/ad103600054f698bb39e96ca1170a72c.vehicle',
    ),
    116 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e8d10773a43f37b19df61b76d034d1af',
      'native_key' => 'OnBeforeUserActivate',
      'filename' => 'modEvent/d77294a0401a5b59ccd56b6e818a9c82.vehicle',
    ),
    117 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '859e315b2bf1d9f8ea830a647382de23',
      'native_key' => 'OnUserActivate',
      'filename' => 'modEvent/22f79d330470738d8e7d73ff4f1d55ff.vehicle',
    ),
    118 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '533fef6b3312413663ceb19c7e3e5b97',
      'native_key' => 'OnBeforeUserDeactivate',
      'filename' => 'modEvent/0c4adb2305f3a42a7b092e57ee557238.vehicle',
    ),
    119 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5c6ae53a938f3cfea51195f557eff860',
      'native_key' => 'OnUserDeactivate',
      'filename' => 'modEvent/2537388255f34acd8c56eaac7011b955.vehicle',
    ),
    120 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '35a97e03090c401ce794295272a15b32',
      'native_key' => 'OnBeforeUserDuplicate',
      'filename' => 'modEvent/fed9b88b7ab99826032bb215a3c96b8e.vehicle',
    ),
    121 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e88ad576ceae9216124aab1f474c1e89',
      'native_key' => 'OnUserDuplicate',
      'filename' => 'modEvent/fa61635d6dcfc98341c26f3276805619.vehicle',
    ),
    122 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3d45c888290284a24811c3419d1f898d',
      'native_key' => 'OnUserChangePassword',
      'filename' => 'modEvent/4a01a7655df8ad15b57914bc6e2d2408.vehicle',
    ),
    123 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '494607711f1fa5b0b498059d2a4b17dc',
      'native_key' => 'OnUserBeforeRemove',
      'filename' => 'modEvent/00b77912ca963074d8f7d0e9700f5e27.vehicle',
    ),
    124 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8146ecf79bfaa93545df8edd42343ccb',
      'native_key' => 'OnUserBeforeSave',
      'filename' => 'modEvent/fd2f46f8d94a089ef28fd2c9c891b8b1.vehicle',
    ),
    125 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fdf37f2e2017c5b86fd1c468fd538c6b',
      'native_key' => 'OnUserSave',
      'filename' => 'modEvent/0c460d9b21cbc5fc9cd6e94305e4e498.vehicle',
    ),
    126 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5f1a9b1e9bc4b5cdda844eaf4188ff91',
      'native_key' => 'OnUserRemove',
      'filename' => 'modEvent/6f6dd8d884e15fac7396ff43bd37a586.vehicle',
    ),
    127 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '42443b961c7803cbc5832e9f5333d70b',
      'native_key' => 'OnUserBeforeAddToGroup',
      'filename' => 'modEvent/26d4491d2b0bf80f0d6eb6165744f190.vehicle',
    ),
    128 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '87c8e57eb72e1413e7ac7434a39a2421',
      'native_key' => 'OnUserAddToGroup',
      'filename' => 'modEvent/6a123ec7dbfbf57bb840b9ce36c9bb25.vehicle',
    ),
    129 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'af7ab92dad9449e06997610665c75d74',
      'native_key' => 'OnUserBeforeRemoveFromGroup',
      'filename' => 'modEvent/a8969f593c125cdb337eb0eff8120465.vehicle',
    ),
    130 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4fe07fca52cba7f7a6a77c11172de442',
      'native_key' => 'OnUserRemoveFromGroup',
      'filename' => 'modEvent/552ff74489f3d87576a49318e207aa97.vehicle',
    ),
    131 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '051d5069d87a8b2de32e491e9d5f4ec9',
      'native_key' => 'OnWebPagePrerender',
      'filename' => 'modEvent/81274f619542b0ee73f5a7fec48c5126.vehicle',
    ),
    132 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2a1edbb356268584bf9a51afe422507f',
      'native_key' => 'OnBeforeCacheUpdate',
      'filename' => 'modEvent/ba1eb00b6cbdcc8caf611cd8b0a3b1b4.vehicle',
    ),
    133 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a253e8576db5ad6fb0cc2a996b6912dd',
      'native_key' => 'OnCacheUpdate',
      'filename' => 'modEvent/344ea890abdf8e27eb6d6213c72ac485.vehicle',
    ),
    134 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'deb30ee79254d7b58a879dbcba05dcdc',
      'native_key' => 'OnLoadWebPageCache',
      'filename' => 'modEvent/9368d87f5da63f9f61db2e61e028704f.vehicle',
    ),
    135 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e5358e50f4457d2451bb5b66bf6e8800',
      'native_key' => 'OnBeforeSaveWebPageCache',
      'filename' => 'modEvent/a49051637929df64a66653ea00821423.vehicle',
    ),
    136 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '66062576a771a55ff107ff970d3b212b',
      'native_key' => 'OnSiteRefresh',
      'filename' => 'modEvent/7bdd8ef86283ce613f9ff8997a34aae2.vehicle',
    ),
    137 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5d1c32784592874a2347d5554b0ceabe',
      'native_key' => 'OnFileManagerDirCreate',
      'filename' => 'modEvent/ce3b587e2a2aa87d30dcbfbdb3044501.vehicle',
    ),
    138 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5c900d7d453da996d10235d4ec3ee061',
      'native_key' => 'OnFileManagerDirRemove',
      'filename' => 'modEvent/3d8c4df67235d8373d6b5cc50ab05d55.vehicle',
    ),
    139 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c4119356901305a2cd537567130f2f21',
      'native_key' => 'OnFileManagerDirRename',
      'filename' => 'modEvent/e5ac7ba2d6e7800e9f3a4537af2b2227.vehicle',
    ),
    140 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a17f8ecb40f3ad21fe333268c68df048',
      'native_key' => 'OnFileManagerFileRename',
      'filename' => 'modEvent/72545bc78980a139a0617b4cdf72b551.vehicle',
    ),
    141 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3b0014ba015b06c6a23711682d8a44d0',
      'native_key' => 'OnFileManagerFileRemove',
      'filename' => 'modEvent/eb49fb752e1dfb1eaa2178586f2f9681.vehicle',
    ),
    142 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5f791a7df4a67c2107f495fb9f2b5713',
      'native_key' => 'OnFileManagerFileUpdate',
      'filename' => 'modEvent/5051405709205af94fe092920a4b1fe4.vehicle',
    ),
    143 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fc31639b0534e64a137f0b06eb4d93d8',
      'native_key' => 'OnFileManagerFileCreate',
      'filename' => 'modEvent/7a2cfb30e56b9fe60164b0540cbea6c0.vehicle',
    ),
    144 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5a20293a1c48572771033c60e1218682',
      'native_key' => 'OnFileManagerBeforeUpload',
      'filename' => 'modEvent/7b6d0a42253c59827f969f52b61dc507.vehicle',
    ),
    145 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '00efbb58e5c38f39932b14386819a7d4',
      'native_key' => 'OnFileManagerUpload',
      'filename' => 'modEvent/bfad276b861c3172c3e74b07881591c2.vehicle',
    ),
    146 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'df7684195ecad4337e42d8c6d519f8d0',
      'native_key' => 'OnFileManagerMoveObject',
      'filename' => 'modEvent/8f77e588ab303b5a21f81ac5ae8e222a.vehicle',
    ),
    147 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '747156ae5979689d895490f70e3c0d8d',
      'native_key' => 'OnFileCreateFormPrerender',
      'filename' => 'modEvent/e63c50550e9563d62405ea79ee50664a.vehicle',
    ),
    148 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '81be05d69abf58f0e2ae9f0dd67fef33',
      'native_key' => 'OnFileEditFormPrerender',
      'filename' => 'modEvent/1f05a4bcbb42479c7a0a7d1cdfae6a77.vehicle',
    ),
    149 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '86aff01bcf5c5f75a3cdf470a8e3ecc8',
      'native_key' => 'OnManagerPageInit',
      'filename' => 'modEvent/09e0241e1409f4dfd89590a239519b96.vehicle',
    ),
    150 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1e616bb5ffb9ed37d9aa63c622388ad3',
      'native_key' => 'OnManagerPageBeforeRender',
      'filename' => 'modEvent/cffc9005a1bd510ae0c300438d330b35.vehicle',
    ),
    151 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8b2ce025dd7e62af8e98cc0e5c90e618',
      'native_key' => 'OnManagerPageAfterRender',
      'filename' => 'modEvent/8d314183a9ff78f71f458b7dd962a6ce.vehicle',
    ),
    152 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '694574a665b48000f5ab59c569f188ec',
      'native_key' => 'OnWebPageInit',
      'filename' => 'modEvent/f7bd0c2735337e22ed8343c894ffa680.vehicle',
    ),
    153 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ddf33fbba1bf0a39a02ea246e2fab330',
      'native_key' => 'OnLoadWebDocument',
      'filename' => 'modEvent/d1ccb01b5082f3e03156dadbf687622f.vehicle',
    ),
    154 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '366b913c2d6f137c045480999c6ee058',
      'native_key' => 'OnParseDocument',
      'filename' => 'modEvent/251a49c7c8d50489f4f59cdf0c09dbdd.vehicle',
    ),
    155 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '54674304a2c1a7305a1b358acb9de628',
      'native_key' => 'OnWebPageComplete',
      'filename' => 'modEvent/ae855861b7d20602f1f2dcd94b1f6df5.vehicle',
    ),
    156 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b3c1a77f01cf58f57548179c85c68091',
      'native_key' => 'OnBeforeManagerPageInit',
      'filename' => 'modEvent/f01e5ed43915e8dffdaa3a97446e7120.vehicle',
    ),
    157 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '67f6d41559fcd81f6c4543f85277474f',
      'native_key' => 'OnPageNotFound',
      'filename' => 'modEvent/0df0a84358b13df4d2e7386f0f9b4938.vehicle',
    ),
    158 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '75d6c6f7da1b1b25811434f3c5eaac0a',
      'native_key' => 'OnHandleRequest',
      'filename' => 'modEvent/5b1c0e373243be965c112e83e9a9a969.vehicle',
    ),
    159 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3c479149e748d04c078231c5bcdf4ef4',
      'native_key' => 'OnMODXInit',
      'filename' => 'modEvent/ad080bb60164b7c082b939b5cd5820df.vehicle',
    ),
    160 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fbf705785d7fec39e36772c00f47fa2d',
      'native_key' => 'OnElementNotFound',
      'filename' => 'modEvent/c907b6f857b1320097aae3f37fd39cda.vehicle',
    ),
    161 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9dde636bc1645a17047d78cf057f95ab',
      'native_key' => 'OnSiteSettingsRender',
      'filename' => 'modEvent/b86ecb00f5af9b4b5cf30cfc379a379e.vehicle',
    ),
    162 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8a7a2438d6fbb90800959a42b698d46d',
      'native_key' => 'OnInitCulture',
      'filename' => 'modEvent/c9e452726c9a5eeb6bbe743d3063acb3.vehicle',
    ),
    163 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ccdcc23f95a1d336f87444f5e3c85e1a',
      'native_key' => 'OnCategorySave',
      'filename' => 'modEvent/6389f1399c3e22c9b97ea54cebd8ac52.vehicle',
    ),
    164 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7669f7ef57529f07805775b62205aa84',
      'native_key' => 'OnCategoryBeforeSave',
      'filename' => 'modEvent/dae2f2e5eb94f3cc9ed76e413b6d3c80.vehicle',
    ),
    165 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '62ef59125d60ca89a9db55014f5f959d',
      'native_key' => 'OnCategoryRemove',
      'filename' => 'modEvent/c7126044bc56452a8e77cd03bfde0c51.vehicle',
    ),
    166 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '47d4c22239059c51ddd0c1d78c6c7d38',
      'native_key' => 'OnCategoryBeforeRemove',
      'filename' => 'modEvent/15239a090697cdf02a16ceae4c3ba27e.vehicle',
    ),
    167 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2b1c1c347867cf8730b348f336a1c5ae',
      'native_key' => 'OnChunkSave',
      'filename' => 'modEvent/9696294544a1ac3101feaa18b1679166.vehicle',
    ),
    168 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '01f75ceed21d1185ee0a5241b21a409a',
      'native_key' => 'OnChunkBeforeSave',
      'filename' => 'modEvent/ac991585181825d0b78ef492b7716f0f.vehicle',
    ),
    169 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ae89a372c834c6c852dae44310e407c2',
      'native_key' => 'OnChunkRemove',
      'filename' => 'modEvent/3dd1c041aef09e89603c0492819445c9.vehicle',
    ),
    170 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7958e679185d2b05ae7daa1e59181415',
      'native_key' => 'OnChunkBeforeRemove',
      'filename' => 'modEvent/6a042669ee58224f271b6855652e286d.vehicle',
    ),
    171 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '167f46ae01e438172fb1a693726b59cc',
      'native_key' => 'OnChunkFormPrerender',
      'filename' => 'modEvent/9f314837464d19240a52c5fc8157da20.vehicle',
    ),
    172 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2a8ff455be46efbebbe1da42356df6d9',
      'native_key' => 'OnChunkFormRender',
      'filename' => 'modEvent/12f702a00066c9d8d7786050f13f7c3e.vehicle',
    ),
    173 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd35b410024238e19a32ceaad67b37b75',
      'native_key' => 'OnBeforeChunkFormSave',
      'filename' => 'modEvent/9f0eea9f33a920ac925803ed53791262.vehicle',
    ),
    174 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '85b196ae642f7ed1c09a825b54130209',
      'native_key' => 'OnChunkFormSave',
      'filename' => 'modEvent/3731a43993a0315b67c9836c67283798.vehicle',
    ),
    175 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd27db03bf0c20ca6f0a0a9ddcfcccbfc',
      'native_key' => 'OnBeforeChunkFormDelete',
      'filename' => 'modEvent/8b03c9e4a8e32cedc6e12891aca1db33.vehicle',
    ),
    176 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0eee65dedbf00ac6f305270f266712fb',
      'native_key' => 'OnChunkFormDelete',
      'filename' => 'modEvent/74e583b4b1abc8d3a9d9151b89aeeb3f.vehicle',
    ),
    177 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cf9bd7f429ec5612b92d14de8aefd7ab',
      'native_key' => 'OnContextSave',
      'filename' => 'modEvent/5d5001281bc0b4753c42b2cc3c8f8461.vehicle',
    ),
    178 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e75ffed185825a0f8a5660204f458fbd',
      'native_key' => 'OnContextBeforeSave',
      'filename' => 'modEvent/5c5256d5d278e3dfd94fe6c3e1c62419.vehicle',
    ),
    179 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '99d43557dd556c0f307a537cdefad5a0',
      'native_key' => 'OnContextRemove',
      'filename' => 'modEvent/0f89930486068ae5b2fc99aed8c0719e.vehicle',
    ),
    180 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bf5a96218f25fb9181c3be3298a61ffe',
      'native_key' => 'OnContextBeforeRemove',
      'filename' => 'modEvent/ed933cbda1c0c9af15482db4b8af6655.vehicle',
    ),
    181 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd1e7f1c47e7b1bcdc03510d26ef0c040',
      'native_key' => 'OnContextFormPrerender',
      'filename' => 'modEvent/bbb673dd9a44f025526443930b71b511.vehicle',
    ),
    182 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '052ec035ce220d4fe8aa922e3ac23227',
      'native_key' => 'OnContextFormRender',
      'filename' => 'modEvent/98ccd53c05baa33c6a1e000fea212f8a.vehicle',
    ),
    183 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3ed497cb893a111203ec29166444a9d5',
      'native_key' => 'OnPluginSave',
      'filename' => 'modEvent/572cf0ad319b23771d1d4c0e4bcde157.vehicle',
    ),
    184 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9caeeb9353c02169ba265278ee4478a1',
      'native_key' => 'OnPluginBeforeSave',
      'filename' => 'modEvent/7c2a1540b0d452934584ac5407f42e52.vehicle',
    ),
    185 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '43ccff3f9cfb0c7e088a0bc2daa49d89',
      'native_key' => 'OnPluginRemove',
      'filename' => 'modEvent/2cfd0adb3f3ff0be0fcd6a7458d80b44.vehicle',
    ),
    186 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '58006e5f3a82d22f2dfd7b0ff3a5eabf',
      'native_key' => 'OnPluginBeforeRemove',
      'filename' => 'modEvent/41a5838a69296cf54ad406ca07f9dad9.vehicle',
    ),
    187 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ab65bb00c6d4aa658b8bd95912b93bd4',
      'native_key' => 'OnPluginFormPrerender',
      'filename' => 'modEvent/5d9ee2dda831887c3847f2909dd5d39f.vehicle',
    ),
    188 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e7e1c72a9b15fb42a217a7e63997f84e',
      'native_key' => 'OnPluginFormRender',
      'filename' => 'modEvent/8f9673a08e3f12d3b9783328b38545da.vehicle',
    ),
    189 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd87ee7565a39d47396c7aa7f356eaf5e',
      'native_key' => 'OnBeforePluginFormSave',
      'filename' => 'modEvent/38fe48749686eb5e10083302a08403d8.vehicle',
    ),
    190 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '344203addc918cdbbc18e6f418f2a4e3',
      'native_key' => 'OnPluginFormSave',
      'filename' => 'modEvent/9772bd536f046a019565531fab043166.vehicle',
    ),
    191 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5cf677660ba93746554ab24205c13e28',
      'native_key' => 'OnBeforePluginFormDelete',
      'filename' => 'modEvent/5a5b05d86cf382400ac8f5b5bf88a634.vehicle',
    ),
    192 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6f258537aa75cb306195b56811881e18',
      'native_key' => 'OnPluginFormDelete',
      'filename' => 'modEvent/6b4d3f4e4f79e220051a92f734f47550.vehicle',
    ),
    193 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '99a1e1ef778f9881ec3c1a416fd76619',
      'native_key' => 'OnPropertySetSave',
      'filename' => 'modEvent/b9e7d71a2473ff3f54a7b9bba3ec2c03.vehicle',
    ),
    194 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9215b3d7ba69794bbc8bf5f6950f3185',
      'native_key' => 'OnPropertySetBeforeSave',
      'filename' => 'modEvent/195022cb2cae6e168e7469ef8cf21b56.vehicle',
    ),
    195 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '559d2bca8d6765e7498ea89c1d7eab0a',
      'native_key' => 'OnPropertySetRemove',
      'filename' => 'modEvent/d8a56f50e58ecd9b1cc9f5aea56e8637.vehicle',
    ),
    196 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f350c096a4e480e5b121a7809aebe913',
      'native_key' => 'OnPropertySetBeforeRemove',
      'filename' => 'modEvent/e8f906d08caac5346d82c816d982addb.vehicle',
    ),
    197 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e22e7cb8434cf3ab821d451b86efe9bc',
      'native_key' => 'OnMediaSourceBeforeFormDelete',
      'filename' => 'modEvent/22bc8f7cf40e812067a11e6149973656.vehicle',
    ),
    198 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0feb4a0eb6c1ea8f8926899fbf63f987',
      'native_key' => 'OnMediaSourceBeforeFormSave',
      'filename' => 'modEvent/c6644f6bcc1a88c2b862a7df7b54e734.vehicle',
    ),
    199 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0da23b6bf3b49a0bdb6c54795d6361b8',
      'native_key' => 'OnMediaSourceGetProperties',
      'filename' => 'modEvent/f93ac6252477b590eee7cc4e7411b793.vehicle',
    ),
    200 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e20b251e2327fbd805a24df4bb538612',
      'native_key' => 'OnMediaSourceFormDelete',
      'filename' => 'modEvent/fc1bb54f8b5a072e3767fe99a0c126e5.vehicle',
    ),
    201 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '81691733740b280ea97e691f176b55a1',
      'native_key' => 'OnMediaSourceFormSave',
      'filename' => 'modEvent/cd328f5e84185b1db1c4ed753c94dbb4.vehicle',
    ),
    202 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c5dcdfeddbf81970b1b65866f069cc85',
      'native_key' => 'OnMediaSourceDuplicate',
      'filename' => 'modEvent/33071fb292577297252d1957608b4417.vehicle',
    ),
    203 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a2f9deb7fc3d59ae6c36fbc5e9633671',
      'native_key' => 'access_category_enabled',
      'filename' => 'modSystemSetting/4ea089faad7fa02efa79c7c0763168ba.vehicle',
    ),
    204 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd344e3f84a53b571508188d18eff1080',
      'native_key' => 'access_context_enabled',
      'filename' => 'modSystemSetting/216d12a570a90d3cff5ec6fc9611f18a.vehicle',
    ),
    205 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9b4800aeed3035878a8eacc98a7c722c',
      'native_key' => 'access_resource_group_enabled',
      'filename' => 'modSystemSetting/afc91bdc3e71a2cbeeaf3daa62154aad.vehicle',
    ),
    206 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f6ce5d3993aafd56cf1162dad9d36fc5',
      'native_key' => 'allow_forward_across_contexts',
      'filename' => 'modSystemSetting/8125823bad6002dfed6436239ed887d4.vehicle',
    ),
    207 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd346b4c4128f7e45a5a9a8935e2bf60d',
      'native_key' => 'allow_manager_login_forgot_password',
      'filename' => 'modSystemSetting/cd669e0e8f4ae6613305fa262bc891a4.vehicle',
    ),
    208 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fe66b28ee6298b6bff23f33b574e0b1b',
      'native_key' => 'allow_multiple_emails',
      'filename' => 'modSystemSetting/c2d54a515c285f59cc3142d401928a09.vehicle',
    ),
    209 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c7790e26dcdf67cc9e270ba1e30aaee7',
      'native_key' => 'allow_tags_in_post',
      'filename' => 'modSystemSetting/c1e3d90defcc03aa1d27bec095ed55c6.vehicle',
    ),
    210 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ff880a47b8168a993433f329554f3e36',
      'native_key' => 'archive_with',
      'filename' => 'modSystemSetting/dfc0680ea63759cdf784b2a044ce5330.vehicle',
    ),
    211 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f4844c9c3150bc99c152edd2683998e9',
      'native_key' => 'auto_menuindex',
      'filename' => 'modSystemSetting/2339258764578a37c8103cbf891320b8.vehicle',
    ),
    212 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '62d47a0f104add8cbd8e7fe15c017f5a',
      'native_key' => 'auto_check_pkg_updates',
      'filename' => 'modSystemSetting/a8207a825a408ff9c7b3d62f469fa435.vehicle',
    ),
    213 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '871d2d0097e58b3a732d07c9bfb817fe',
      'native_key' => 'auto_check_pkg_updates_cache_expire',
      'filename' => 'modSystemSetting/d7831a581f7d09f2eb0a95934e5575f5.vehicle',
    ),
    214 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cd4e02c2485fe5473ee7ca167ebafc91',
      'native_key' => 'automatic_alias',
      'filename' => 'modSystemSetting/0375115d0d0e425af1e7e9392f1cc6d4.vehicle',
    ),
    215 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9aaa83b32ecaa6e155b9ba9ae02bf187',
      'native_key' => 'base_help_url',
      'filename' => 'modSystemSetting/323e898ef0efe5af532df1c66ed9cf0f.vehicle',
    ),
    216 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7e9433aeef437bdcb114868cd5cb1ed8',
      'native_key' => 'blocked_minutes',
      'filename' => 'modSystemSetting/b05c6697e7e90b65a59d00649ca70cfb.vehicle',
    ),
    217 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ac0be456691af7a3e6bd49f14e9c3d3e',
      'native_key' => 'cache_action_map',
      'filename' => 'modSystemSetting/49cb259fbacb80517a0d310c3c3e8256.vehicle',
    ),
    218 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b637ee079ffc7cbeb8465354dfc579eb',
      'native_key' => 'cache_alias_map',
      'filename' => 'modSystemSetting/60db9e04d8587cb3253bdf749e406d28.vehicle',
    ),
    219 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '722d4594bbfc8ffe6a479b221de60c42',
      'native_key' => 'cache_context_settings',
      'filename' => 'modSystemSetting/517089a7f453df54118f4ee844d0f054.vehicle',
    ),
    220 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0be8b5fbf9b96f3a49c3073a3f6318c2',
      'native_key' => 'cache_db',
      'filename' => 'modSystemSetting/de7cb8b7c51deeaba719762ab5d58779.vehicle',
    ),
    221 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4bc8fae77de0289d3f83a563a8c31542',
      'native_key' => 'cache_db_expires',
      'filename' => 'modSystemSetting/40e092e19aec00feadb5111b443959e3.vehicle',
    ),
    222 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c1e9e77ed4dff4ca227a4d4087972cae',
      'native_key' => 'cache_db_session',
      'filename' => 'modSystemSetting/0cdb679a1ba5e9eb7c9e01a369485457.vehicle',
    ),
    223 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a66a819f6c560aa0bb2ed52d6e7fc2ec',
      'native_key' => 'cache_db_session_lifetime',
      'filename' => 'modSystemSetting/695892cb5c4da64750009e7bcffcde79.vehicle',
    ),
    224 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f9866b9f61d8dc3d7e1a183e1cd5ca6d',
      'native_key' => 'cache_default',
      'filename' => 'modSystemSetting/3fc1301325594639bde1d73995e38594.vehicle',
    ),
    225 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fdcf25123e13122b266e264c4448f484',
      'native_key' => 'cache_disabled',
      'filename' => 'modSystemSetting/a03339467fb0f64748e045950175fe68.vehicle',
    ),
    226 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4ef4a7def6956da0fb3d04318dbea29f',
      'native_key' => 'cache_expires',
      'filename' => 'modSystemSetting/bdb0cdaeb30c5ebb7844b8f9732f7045.vehicle',
    ),
    227 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '18f9525931d3620f04e61e7e38f7c51b',
      'native_key' => 'cache_format',
      'filename' => 'modSystemSetting/26f252fa0ce2890aa6b6962bf9014882.vehicle',
    ),
    228 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b43e93d7213ded098a687d09c9c28098',
      'native_key' => 'cache_handler',
      'filename' => 'modSystemSetting/5b45f56dbdf077ac46d85d2f6a28ce56.vehicle',
    ),
    229 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '81bc656937664d67b740e173ccc649a7',
      'native_key' => 'cache_lang_js',
      'filename' => 'modSystemSetting/7b3d654a792d764a53fbb1626193e851.vehicle',
    ),
    230 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '114ebe9b07ea381a4dbe4a3c9cc407a5',
      'native_key' => 'cache_lexicon_topics',
      'filename' => 'modSystemSetting/000765650550abb6fa44e6d513034161.vehicle',
    ),
    231 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '04222a2d2615d31a78f4fa83c977ea2a',
      'native_key' => 'cache_noncore_lexicon_topics',
      'filename' => 'modSystemSetting/02a01511fb95451eb543d720eaefd6ed.vehicle',
    ),
    232 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0b7e7f38c61a5a26df164bb6ad6da5e8',
      'native_key' => 'cache_resource',
      'filename' => 'modSystemSetting/96fdc74ab8632bf434027bcef215fca9.vehicle',
    ),
    233 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd0d01740721d228922ae9a5e71518ea3',
      'native_key' => 'cache_resource_expires',
      'filename' => 'modSystemSetting/029e1e383ff4746a2e2086dcace6ab06.vehicle',
    ),
    234 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c03004870dd2b8729a824ba8611105d3',
      'native_key' => 'cache_scripts',
      'filename' => 'modSystemSetting/01d7dbfc1ae5c69058e9293d025d4e67.vehicle',
    ),
    235 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4e041203b6cd7f46f8c4515bc2175454',
      'native_key' => 'cache_system_settings',
      'filename' => 'modSystemSetting/3a0bd34cf9206c079e2fab8b783503f4.vehicle',
    ),
    236 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6de2a985a7db3f5ee25dd4262923e69d',
      'native_key' => 'clear_cache_refresh_trees',
      'filename' => 'modSystemSetting/74d42f1c537232a6a42f852545031868.vehicle',
    ),
    237 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3aacdcff4fe0b1522fd7a6e38ec9ecb0',
      'native_key' => 'compress_css',
      'filename' => 'modSystemSetting/9fa6f1f7b0c258dfb6ac81ae7cfd2858.vehicle',
    ),
    238 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1ef2c9a7ab708949f487d4f9dd49f339',
      'native_key' => 'compress_js',
      'filename' => 'modSystemSetting/0ee588b97aeebfad9ee1df921b1dc24c.vehicle',
    ),
    239 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5b016c5c80ea322204e7d3c63d627b63',
      'native_key' => 'compress_js_max_files',
      'filename' => 'modSystemSetting/96fe95834ce4e0d9099e03827f313897.vehicle',
    ),
    240 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c2af5407a60c981e77c8ef94d37269ad',
      'native_key' => 'compress_js_groups',
      'filename' => 'modSystemSetting/a0206b446f64d783ff610e3812ca35f6.vehicle',
    ),
    241 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd3682e06f616398f7349297bbdde17e3',
      'native_key' => 'confirm_navigation',
      'filename' => 'modSystemSetting/456a4642b03cb7dff43afdf247953930.vehicle',
    ),
    242 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd0dddd3e2ab5bc9a0a10f1004ff10bfe',
      'native_key' => 'container_suffix',
      'filename' => 'modSystemSetting/9faf1df0e6bc85bc60b66624716fcec9.vehicle',
    ),
    243 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cf9587b6e98b7cddb9e3c1576d5a235e',
      'native_key' => 'context_tree_sort',
      'filename' => 'modSystemSetting/ee9f7b7c6ee40cc8ed27c3cd0bf2b44f.vehicle',
    ),
    244 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '956fa6f811aa7c0b1a76cab40e4e5417',
      'native_key' => 'context_tree_sortby',
      'filename' => 'modSystemSetting/28d47c490e88de906fde5ab45cd2c3a4.vehicle',
    ),
    245 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f47667ec8452b48cc764e0282a5045ab',
      'native_key' => 'context_tree_sortdir',
      'filename' => 'modSystemSetting/b00c639ae6c4a52a9238fa35537a8ad9.vehicle',
    ),
    246 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6e652c1b6066547f7be288486b71ab4c',
      'native_key' => 'cultureKey',
      'filename' => 'modSystemSetting/7669c9eebfba7bb40c6c8101581d3c33.vehicle',
    ),
    247 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ee6a66b7b8d6f675c93ad040886ee608',
      'native_key' => 'date_timezone',
      'filename' => 'modSystemSetting/bd9493db34563115dc3cb1ada95f690f.vehicle',
    ),
    248 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '96e99ea29865ea1c016b959e4793e3ea',
      'native_key' => 'debug',
      'filename' => 'modSystemSetting/6d1c26fe9fc33d8177140cc1f7ff7373.vehicle',
    ),
    249 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd1931d73231edf0c2470255edb8809de',
      'native_key' => 'default_duplicate_publish_option',
      'filename' => 'modSystemSetting/3fcc5ab9093bf8ced48b44fd1248c913.vehicle',
    ),
    250 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '162c8b9a9b8a5404251873b830d69ccc',
      'native_key' => 'default_media_source',
      'filename' => 'modSystemSetting/a0bad9d809f988b23659e3835e66d6b0.vehicle',
    ),
    251 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bf3d07aa97f5459abf4b0d5409c3bc8a',
      'native_key' => 'default_per_page',
      'filename' => 'modSystemSetting/b76e95b933d330bb047044ceda243b12.vehicle',
    ),
    252 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '419574dfdb02b0c20ede8502bbf775cd',
      'native_key' => 'default_context',
      'filename' => 'modSystemSetting/677bde8ae0afb666a8e1323439f86572.vehicle',
    ),
    253 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '417cb141d0f8145bf04b3a21ff71adc4',
      'native_key' => 'default_template',
      'filename' => 'modSystemSetting/0facc8898b3a11632850211a405d3dc4.vehicle',
    ),
    254 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '462d4ec71bf67bacd81f352718611d7b',
      'native_key' => 'default_content_type',
      'filename' => 'modSystemSetting/f01081a830d31490a31a86d20dc9a16a.vehicle',
    ),
    255 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1d0cdf5170fef7d1e78463e045d2625b',
      'native_key' => 'editor_css_path',
      'filename' => 'modSystemSetting/9ecb756d31c4b49682de93ddbb39a317.vehicle',
    ),
    256 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ce7a81c845fdcc78375de82003cf3f8a',
      'native_key' => 'editor_css_selectors',
      'filename' => 'modSystemSetting/8c768aa54eec22f03eb61e2a14fbc6e2.vehicle',
    ),
    257 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ad7539c28dcf575780b70ecf8249f98d',
      'native_key' => 'emailsender',
      'filename' => 'modSystemSetting/001e7b7790f39687f93a8ac3a1447e8c.vehicle',
    ),
    258 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '32c32d201678e39f509358e38596b620',
      'native_key' => 'emailsubject',
      'filename' => 'modSystemSetting/c37cae59c6b108a93a16434208efc50e.vehicle',
    ),
    259 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a51ff20caa27024c51119fd72075ba2d',
      'native_key' => 'enable_dragdrop',
      'filename' => 'modSystemSetting/7d3cf8acdead7eff2a6aeb95f5f8dfa5.vehicle',
    ),
    260 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4e59dbf086fbfd47b0f65085b66bfd85',
      'native_key' => 'error_page',
      'filename' => 'modSystemSetting/d3900822bf01529ff48154a50e47f041.vehicle',
    ),
    261 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f6a8000af5d38fe4cf240a6a92205a4d',
      'native_key' => 'failed_login_attempts',
      'filename' => 'modSystemSetting/4ca21da56e30ee371bd3ce95d2522d3d.vehicle',
    ),
    262 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a99b4047f1c0dac1f340f6cd3859a640',
      'native_key' => 'fe_editor_lang',
      'filename' => 'modSystemSetting/fa2651d44d4285b1b3523caf09c598bd.vehicle',
    ),
    263 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '150682324f4527b97b7536303e61a725',
      'native_key' => 'feed_modx_news',
      'filename' => 'modSystemSetting/5891f73c35fd2eb83224b0bde86dce99.vehicle',
    ),
    264 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '77c69414a84d7ebe294a93426b5d0c13',
      'native_key' => 'feed_modx_news_enabled',
      'filename' => 'modSystemSetting/d06da4f7bf3634459a990bd73722275b.vehicle',
    ),
    265 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0a85c15ea32dae619bb2ccf27605e746',
      'native_key' => 'feed_modx_security',
      'filename' => 'modSystemSetting/be98a12d086678b84f5d3496ba0ab226.vehicle',
    ),
    266 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b23e5bcb7eeddf3cfe6a0b51027b79ec',
      'native_key' => 'feed_modx_security_enabled',
      'filename' => 'modSystemSetting/6e6202169416a1b68007c476bb14078c.vehicle',
    ),
    267 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e1bf3243ea4a64f609036a47612f4e6b',
      'native_key' => 'filemanager_path',
      'filename' => 'modSystemSetting/1136287d2a47a5f23bc628c354cb3d15.vehicle',
    ),
    268 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '064b6978a4090aa6bec1c5e883ff3267',
      'native_key' => 'filemanager_path_relative',
      'filename' => 'modSystemSetting/5c98b738d61db1bf718f082dfc1e90dc.vehicle',
    ),
    269 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4ab1e93f8052cfd9a47d593c63027235',
      'native_key' => 'filemanager_url',
      'filename' => 'modSystemSetting/37e1746e1c8f2ee926a346e26738ba14.vehicle',
    ),
    270 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '55447bb7954fd51e2de02a531271ad37',
      'native_key' => 'filemanager_url_relative',
      'filename' => 'modSystemSetting/171d416a53b7b44919de9805786f70b4.vehicle',
    ),
    271 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bc1d98999dcbc234e266b33e4dbe6709',
      'native_key' => 'forgot_login_email',
      'filename' => 'modSystemSetting/bf459c44f82e5cd7f79a7c2941dd1ad2.vehicle',
    ),
    272 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7afc0ee5d2f8da66195bd0693fc030b4',
      'native_key' => 'form_customization_use_all_groups',
      'filename' => 'modSystemSetting/f30ff0b6196b39c7d48911910111128a.vehicle',
    ),
    273 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '61f941e41e8f3e8000bbe0e7f2e05caf',
      'native_key' => 'forward_merge_excludes',
      'filename' => 'modSystemSetting/7d86d23f968b7c82882bc6c4592180d7.vehicle',
    ),
    274 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c67f088867da19fa1d77690136df0bfe',
      'native_key' => 'friendly_alias_lowercase_only',
      'filename' => 'modSystemSetting/fa1c2603c4f1112322f4cc88986f8b4b.vehicle',
    ),
    275 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8847ee0d4092f1d88b6ec160ad41bb00',
      'native_key' => 'friendly_alias_max_length',
      'filename' => 'modSystemSetting/4726e300834eb2868c019ed5b9f3dbf1.vehicle',
    ),
    276 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6688dd7e8facb2be41fe1ea242763ad7',
      'native_key' => 'friendly_alias_realtime',
      'filename' => 'modSystemSetting/3ab5dabd55db9cf48c566ecaba17da2c.vehicle',
    ),
    277 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f4980466606c02b8f610c4204db0849f',
      'native_key' => 'friendly_alias_restrict_chars',
      'filename' => 'modSystemSetting/92eb9de13035f3d95583ac499c79d6c2.vehicle',
    ),
    278 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e24ea2d3c21bb4747a806008d3eb4b62',
      'native_key' => 'friendly_alias_restrict_chars_pattern',
      'filename' => 'modSystemSetting/3b39255f4bddb0c3167feba84c94cccd.vehicle',
    ),
    279 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4e83bc0aa70b370f1e1169a761893219',
      'native_key' => 'friendly_alias_strip_element_tags',
      'filename' => 'modSystemSetting/ee3f703f73dd7033d52decffbdcd1d3f.vehicle',
    ),
    280 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e9f1caacc55bac064edb12517b595208',
      'native_key' => 'friendly_alias_translit',
      'filename' => 'modSystemSetting/6b450c60c515591005abbb8b1a1aeff3.vehicle',
    ),
    281 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e27f1215a9abeb0c7d6f94e499835096',
      'native_key' => 'friendly_alias_translit_class',
      'filename' => 'modSystemSetting/44756882d097dfccd0ce1fe0f405376a.vehicle',
    ),
    282 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '49f3f71fc6114a1b98dd844f1b7b7edd',
      'native_key' => 'friendly_alias_translit_class_path',
      'filename' => 'modSystemSetting/0a7fa52754cfb1797ed26bdde9f616cf.vehicle',
    ),
    283 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '204e684e8f9d74a1cd71126c5573c93c',
      'native_key' => 'friendly_alias_trim_chars',
      'filename' => 'modSystemSetting/23cc0125a0e4c285037f57c12685d0aa.vehicle',
    ),
    284 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3196f2db4acbfb8612befd1f419ca0a2',
      'native_key' => 'friendly_alias_word_delimiter',
      'filename' => 'modSystemSetting/3af5e80154b43745b86609da87caa488.vehicle',
    ),
    285 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ed343eb6bdd8f4a55d0ae2b17a9411eb',
      'native_key' => 'friendly_alias_word_delimiters',
      'filename' => 'modSystemSetting/9eff54d4b147d16d162183f850cb7527.vehicle',
    ),
    286 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e2b6bebd0ad06d982e101486c8087c46',
      'native_key' => 'friendly_urls',
      'filename' => 'modSystemSetting/49ba387dcac2613e03bfc94ac83bf919.vehicle',
    ),
    287 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b8d542bf25f542c7b1e25ff5c8685215',
      'native_key' => 'friendly_urls_strict',
      'filename' => 'modSystemSetting/9d5df82ada4dfa126d4da150dca8a238.vehicle',
    ),
    288 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '26ab925e2fe54a743cb3c543e1c5f8ff',
      'native_key' => 'use_frozen_parent_uris',
      'filename' => 'modSystemSetting/788497a652944641f6996bb279db160a.vehicle',
    ),
    289 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '82c256e32b9ef6aa4a871acb1e6de590',
      'native_key' => 'global_duplicate_uri_check',
      'filename' => 'modSystemSetting/4c3c514e5804be629618e997ad38c1e8.vehicle',
    ),
    290 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c5fb3c2f4d8a64c05257a3065253589f',
      'native_key' => 'hidemenu_default',
      'filename' => 'modSystemSetting/9f1ab9c51c40752600aab9c4ea0a0a1c.vehicle',
    ),
    291 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e79ec4f3d2d4866ca59bd04d99311d5e',
      'native_key' => 'inline_help',
      'filename' => 'modSystemSetting/dc49bd33bfb97494314af9ec7e0c5d48.vehicle',
    ),
    292 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bf4e49b3c34e71ceca7bd5d92c4c00ce',
      'native_key' => 'locale',
      'filename' => 'modSystemSetting/98dbb226f8eb2d60c1089bac8d2a796e.vehicle',
    ),
    293 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '904bf3cf056878ebde7b04c402ef2697',
      'native_key' => 'log_level',
      'filename' => 'modSystemSetting/327ad5df7d1a8550465d7e784a4c64c7.vehicle',
    ),
    294 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cf9ec75db828f4f9e9dad0e9bdfab95b',
      'native_key' => 'log_target',
      'filename' => 'modSystemSetting/272bc19a4935b4c4c9e4a2feac224bc9.vehicle',
    ),
    295 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e66aa93f23de5b97b5a49247a535837c',
      'native_key' => 'link_tag_scheme',
      'filename' => 'modSystemSetting/5749b7d42ae35bbce02b98c3a0399681.vehicle',
    ),
    296 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4a8beafe159fb70603bdafc2a5a9cd1e',
      'native_key' => 'lock_ttl',
      'filename' => 'modSystemSetting/8da9f5a8f2857c79f12a7d6d9401375c.vehicle',
    ),
    297 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '83a4d68dcd545f4ebe67acbc02071098',
      'native_key' => 'mail_charset',
      'filename' => 'modSystemSetting/a2367a7995b9f88571730bc42cf07c3a.vehicle',
    ),
    298 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6d4d6f4ccbe998d791f27dea4cfe45ab',
      'native_key' => 'mail_encoding',
      'filename' => 'modSystemSetting/f54e8d51d8e0c3482af67fdbd0003443.vehicle',
    ),
    299 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c9447b9103cb8373f74b36ae0c4a14f9',
      'native_key' => 'mail_use_smtp',
      'filename' => 'modSystemSetting/f73ec127daf2d63a86a958fadec5917a.vehicle',
    ),
    300 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c688d12ad604719bc6c21ae1d3f8708f',
      'native_key' => 'mail_smtp_auth',
      'filename' => 'modSystemSetting/a456972d447789509d3c955ccd884b00.vehicle',
    ),
    301 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '99f3b4a87daf5d73df0a23100b3df761',
      'native_key' => 'mail_smtp_helo',
      'filename' => 'modSystemSetting/e07cadffb6a80d5b3e14c02902a7364e.vehicle',
    ),
    302 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '61149dc14955f6cb105240e633ada4aa',
      'native_key' => 'mail_smtp_hosts',
      'filename' => 'modSystemSetting/3777f71dc962021096dc61e61787b182.vehicle',
    ),
    303 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f444475e2f970aed27e50c53afb9f34e',
      'native_key' => 'mail_smtp_keepalive',
      'filename' => 'modSystemSetting/2b9f281e0f99ae19d2b893a379461fd3.vehicle',
    ),
    304 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c561b702ecdb37f70168c01c5ec3b906',
      'native_key' => 'mail_smtp_pass',
      'filename' => 'modSystemSetting/82d244d9811de7010cf015e88b86a249.vehicle',
    ),
    305 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd3484154d29460c06b32082fdfc953e2',
      'native_key' => 'mail_smtp_port',
      'filename' => 'modSystemSetting/2a9d9187f0212316e0e1b9552069dfed.vehicle',
    ),
    306 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0a1fb2c547b923c660c29176a6032e6a',
      'native_key' => 'mail_smtp_prefix',
      'filename' => 'modSystemSetting/59ee1aceb4750b7f633ccd7da1bc1818.vehicle',
    ),
    307 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'acc855d7d76c5827dac31f3180ad0191',
      'native_key' => 'mail_smtp_single_to',
      'filename' => 'modSystemSetting/523aee3c655234d7e36874bc3ae600d0.vehicle',
    ),
    308 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7a57ee9963517c298f5cab0cda99271a',
      'native_key' => 'mail_smtp_timeout',
      'filename' => 'modSystemSetting/07ae33a66f8349ccdf3cb9e9319623bc.vehicle',
    ),
    309 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e8fdc4136e36799ca30eba79b56657e9',
      'native_key' => 'mail_smtp_user',
      'filename' => 'modSystemSetting/b47da2c42d49b28366a884a337b91164.vehicle',
    ),
    310 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '81dd3ac01cb14e2322fab36eaf1c9037',
      'native_key' => 'manager_date_format',
      'filename' => 'modSystemSetting/89cc36ce636866a6ff9f7f6008d90ece.vehicle',
    ),
    311 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '553549c69c50e63d991646857a19d27a',
      'native_key' => 'manager_favicon_url',
      'filename' => 'modSystemSetting/e0d1c24531afdf309550b733d0436ad0.vehicle',
    ),
    312 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c26b6bc95f80542b0af9dbfcd5808536',
      'native_key' => 'manager_html5_cache',
      'filename' => 'modSystemSetting/5ff249df7115dd943ccd6b969c1bdbd2.vehicle',
    ),
    313 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e0576b291c161d38346961c284837f48',
      'native_key' => 'manager_js_cache_file_locking',
      'filename' => 'modSystemSetting/94594976abad586495236da41e7dfed1.vehicle',
    ),
    314 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '886130b145c5930e650cac5b6c346cf7',
      'native_key' => 'manager_js_cache_max_age',
      'filename' => 'modSystemSetting/818c81c6def1218afa8a5202e46b4794.vehicle',
    ),
    315 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a55540fb7cf89b72dc32cba52c9234ad',
      'native_key' => 'manager_js_document_root',
      'filename' => 'modSystemSetting/84c0fc606a24bc09cc05781a6fbf7678.vehicle',
    ),
    316 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4719093a32f3b153e2b13bd3f2292283',
      'native_key' => 'manager_js_zlib_output_compression',
      'filename' => 'modSystemSetting/502ac445995c838b9397e10cb4fbda30.vehicle',
    ),
    317 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bed822164aca3cf57a8878479c67eecb',
      'native_key' => 'manager_time_format',
      'filename' => 'modSystemSetting/ae0708c1736d81d13b942d29cf6d20ec.vehicle',
    ),
    318 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8cd1a8b6cbb60292243a8d5fbdded4a1',
      'native_key' => 'manager_direction',
      'filename' => 'modSystemSetting/5cbd47ee391e8f7b659838b45f4b68c8.vehicle',
    ),
    319 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c7166e6f96a111b8606c144f7557a5d9',
      'native_key' => 'manager_lang_attribute',
      'filename' => 'modSystemSetting/ae32df58e927adcc3ecb64fa5cd5f116.vehicle',
    ),
    320 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6e8a96a94ba0afa27359d6d521ca06e2',
      'native_key' => 'manager_language',
      'filename' => 'modSystemSetting/6c0ba30cd6c7f7d29e9cde7ab21e7c62.vehicle',
    ),
    321 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6dde31bc650f10d23e111a2ffec1ec8f',
      'native_key' => 'manager_login_url_alternate',
      'filename' => 'modSystemSetting/ae3901bdcaa4247ab45b6510439b909b.vehicle',
    ),
    322 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e1d7807c19d14d7462ff3741d7e54f78',
      'native_key' => 'manager_theme',
      'filename' => 'modSystemSetting/0c337050cdd4b0091009bd82dca763d6.vehicle',
    ),
    323 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f805deacea105d6928f0ade30f66125e',
      'native_key' => 'manager_week_start',
      'filename' => 'modSystemSetting/765516e6642d5517fc241247385c81ca.vehicle',
    ),
    324 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '658c6b046028e1421f90aa940834a51f',
      'native_key' => 'modx_browser_tree_hide_files',
      'filename' => 'modSystemSetting/59204c3b988a02036320212136b2835d.vehicle',
    ),
    325 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '540f6c2d7009862efe706a38c860628f',
      'native_key' => 'modx_browser_tree_hide_tooltips',
      'filename' => 'modSystemSetting/886be3b9a17ebd7f5fde6f29b2fc0533.vehicle',
    ),
    326 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a3d0d399266d1182034476c012a13508',
      'native_key' => 'modx_browser_default_sort',
      'filename' => 'modSystemSetting/18a24387441d68dd36c67ab86d2e35fb.vehicle',
    ),
    327 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8e3e56a2f8e4b4231698cfe967b1981a',
      'native_key' => 'modx_browser_default_viewmode',
      'filename' => 'modSystemSetting/ca5e3e13fc85eddd7c71dd4496c53cb1.vehicle',
    ),
    328 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c7b84d6fca5adcb6269e34747f432cf6',
      'native_key' => 'modx_charset',
      'filename' => 'modSystemSetting/c556852a49e4fb03fb2ff698fe16767c.vehicle',
    ),
    329 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd4d92ce17979d933375b61e5bb9e135b',
      'native_key' => 'principal_targets',
      'filename' => 'modSystemSetting/3b094d4d7d2fca8ab135a8fc7670260b.vehicle',
    ),
    330 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '265128cd8bd0206dca2851f7ca9bad3c',
      'native_key' => 'proxy_auth_type',
      'filename' => 'modSystemSetting/0f184b49ad03ad79134cbc10ea8c8956.vehicle',
    ),
    331 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0967fc899c743a0945bb8fb17a1c1b70',
      'native_key' => 'proxy_host',
      'filename' => 'modSystemSetting/af622d44294aedbdc22c9fdef689c61b.vehicle',
    ),
    332 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '64a6ef596aeb07578d3806af15a034e6',
      'native_key' => 'proxy_password',
      'filename' => 'modSystemSetting/440a41ac4cb9c61b19eb7b1784fb4cbb.vehicle',
    ),
    333 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b7e2f21c54d1f371c1b36aca851a0e09',
      'native_key' => 'proxy_port',
      'filename' => 'modSystemSetting/16b59556d6ae84a60b074345db6247db.vehicle',
    ),
    334 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0937e680ccce1065dbbc26ad929c3fed',
      'native_key' => 'proxy_username',
      'filename' => 'modSystemSetting/e65b07e0b29b4fe65404b108c1fa7311.vehicle',
    ),
    335 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0b45a8590ca6b74889ecb356e4a394ed',
      'native_key' => 'password_generated_length',
      'filename' => 'modSystemSetting/3de8b2d6c1e52973d22f2560990587e6.vehicle',
    ),
    336 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '70f1a5d06b7758c175a80e1ff3bff4c9',
      'native_key' => 'password_min_length',
      'filename' => 'modSystemSetting/3d4ac56b6b150507a87f37eaf326cd14.vehicle',
    ),
    337 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b6390bd4bc5ed472d02546bf79e06782',
      'native_key' => 'phpthumb_allow_src_above_docroot',
      'filename' => 'modSystemSetting/2065815285ee53ff4c7f4c01f4161e57.vehicle',
    ),
    338 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5b5fa3307bb2ff0b63e46193a5253154',
      'native_key' => 'phpthumb_cache_maxage',
      'filename' => 'modSystemSetting/e65e50d108557beba3f979f3219767b8.vehicle',
    ),
    339 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'be738a965b32794d97bc8d5d8e48972f',
      'native_key' => 'phpthumb_cache_maxsize',
      'filename' => 'modSystemSetting/684ed19dbd727b477e304829fc202e3e.vehicle',
    ),
    340 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c14dc59c5989d9b11cf72b1be20622f8',
      'native_key' => 'phpthumb_cache_maxfiles',
      'filename' => 'modSystemSetting/e17bab86704a91795dde089745aeec15.vehicle',
    ),
    341 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9b1ce9d35133347d0de9143e7300f787',
      'native_key' => 'phpthumb_cache_source_enabled',
      'filename' => 'modSystemSetting/68c0b4813a84a739c65baccef20db78c.vehicle',
    ),
    342 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '21c0efec306726d8f90779a11bc95e76',
      'native_key' => 'phpthumb_document_root',
      'filename' => 'modSystemSetting/74d6cabb4f2888b3a4774904d945edad.vehicle',
    ),
    343 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7b6661b85e747b42f23e2c50b5d65842',
      'native_key' => 'phpthumb_error_bgcolor',
      'filename' => 'modSystemSetting/19ff75a37b2e3043bfbcf878618aa974.vehicle',
    ),
    344 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '10f30a4234a6578a4d5c2f4894c819ed',
      'native_key' => 'phpthumb_error_textcolor',
      'filename' => 'modSystemSetting/78e1610e3637ad8646bad8040a6fb1a8.vehicle',
    ),
    345 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cd0d18c46ae54187f32f1319f3468039',
      'native_key' => 'phpthumb_error_fontsize',
      'filename' => 'modSystemSetting/1416f5082306176074e11c14a6808dac.vehicle',
    ),
    346 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1d660743eee793caacf947e55b7e70f8',
      'native_key' => 'phpthumb_far',
      'filename' => 'modSystemSetting/2a3a0d44f0807a4898aaca8b74030c54.vehicle',
    ),
    347 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3e4608a7294966209774f091defe8c8e',
      'native_key' => 'phpthumb_imagemagick_path',
      'filename' => 'modSystemSetting/a7388fad3e666ff005a9025b380f73f6.vehicle',
    ),
    348 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c21da0c530f071893ba220c361a327ef',
      'native_key' => 'phpthumb_nohotlink_enabled',
      'filename' => 'modSystemSetting/3a2ec9f2eaa5b1e80154f3f081887652.vehicle',
    ),
    349 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aaac4c779f3a00647c08569c436ab6ca',
      'native_key' => 'phpthumb_nohotlink_erase_image',
      'filename' => 'modSystemSetting/9ef00020aa241e4e3318c92a7225ad51.vehicle',
    ),
    350 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '186af76085b294cdc2dd7d9bf2c89035',
      'native_key' => 'phpthumb_nohotlink_valid_domains',
      'filename' => 'modSystemSetting/31c580f6c9394720b56af429a2b61ece.vehicle',
    ),
    351 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8e67419b4af0b4e294a25a2a985110eb',
      'native_key' => 'phpthumb_nohotlink_text_message',
      'filename' => 'modSystemSetting/e8b49c556b04aa59edced0a0f32200ea.vehicle',
    ),
    352 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'df81103d3729e7a0511039692eab9c69',
      'native_key' => 'phpthumb_nooffsitelink_enabled',
      'filename' => 'modSystemSetting/dce83b4a7387461dc667c3f6d62bc16f.vehicle',
    ),
    353 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ed4e1a88e58b476e6ba61f4991c0ea6d',
      'native_key' => 'phpthumb_nooffsitelink_erase_image',
      'filename' => 'modSystemSetting/f6ec5a89ae9bfc21adf83c1cbc78b0db.vehicle',
    ),
    354 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b03b73b3c7c7bd1fc1e38369fe720849',
      'native_key' => 'phpthumb_nooffsitelink_require_refer',
      'filename' => 'modSystemSetting/557af91f1985b99958c1c87baedde50a.vehicle',
    ),
    355 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1edf122b52604d8b5a3fa02394a41cba',
      'native_key' => 'phpthumb_nooffsitelink_text_message',
      'filename' => 'modSystemSetting/8c4ae9fd4bd6e7b59760c321acbc2e0c.vehicle',
    ),
    356 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6c5f62395adbf3203edf9a0aab123891',
      'native_key' => 'phpthumb_nooffsitelink_valid_domains',
      'filename' => 'modSystemSetting/172379b6bb630d671137f78b9e09174b.vehicle',
    ),
    357 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '844ff0e7bdeb159d7ecf4df46148afb8',
      'native_key' => 'phpthumb_nooffsitelink_watermark_src',
      'filename' => 'modSystemSetting/7c1e750a566b49ad370d2852fbeab04c.vehicle',
    ),
    358 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3d35287bdb3503a5c0e3768fd22396d7',
      'native_key' => 'phpthumb_zoomcrop',
      'filename' => 'modSystemSetting/07902e26a1e7d306c5878dd694ebb12c.vehicle',
    ),
    359 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a216a91d5f074dc4f7b8545f35eeb56d',
      'native_key' => 'publish_default',
      'filename' => 'modSystemSetting/4aac0decce607d83acfba66853fb50d8.vehicle',
    ),
    360 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '43747d1d1767f17e8baae3b715d580d2',
      'native_key' => 'rb_base_dir',
      'filename' => 'modSystemSetting/583fd91e46cbf3b37711316e4a4fb835.vehicle',
    ),
    361 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '743b7a91566efd59c5c9cf0391de9263',
      'native_key' => 'rb_base_url',
      'filename' => 'modSystemSetting/f55e2ec644ef523a4bc4625e6060d578.vehicle',
    ),
    362 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '40e6e9a8d528d560ad3585c64c450358',
      'native_key' => 'request_controller',
      'filename' => 'modSystemSetting/e5bd9d5667d715d52be98d8f3fabf30f.vehicle',
    ),
    363 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5b9a37621b5c14dbcd259f1f2150b40c',
      'native_key' => 'request_method_strict',
      'filename' => 'modSystemSetting/b09c892e728d0a4c748ae08102b91f71.vehicle',
    ),
    364 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2fa9d825f2c340ed9a82d406aa0826af',
      'native_key' => 'request_param_alias',
      'filename' => 'modSystemSetting/e1c4ffc11689d4e899bdaca044124506.vehicle',
    ),
    365 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f607cdeab1ef42ad1c8fa5bac2516718',
      'native_key' => 'request_param_id',
      'filename' => 'modSystemSetting/9ecc0c46ee7e10183583da5aed2fa723.vehicle',
    ),
    366 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8cd5487d84bac35c782d47183f2009a6',
      'native_key' => 'resolve_hostnames',
      'filename' => 'modSystemSetting/754acc5c9e69498e7a70927045c8c933.vehicle',
    ),
    367 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f0bde36ebe445f2c4bd0cbeaeacf1b36',
      'native_key' => 'resource_tree_node_name',
      'filename' => 'modSystemSetting/d681cd8b11bc5d22f2b9bbff1647a04f.vehicle',
    ),
    368 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c2e9e655268e1b7ba3ceb203a2759a27',
      'native_key' => 'resource_tree_node_name_fallback',
      'filename' => 'modSystemSetting/039e1d527fd19138854452705b76854f.vehicle',
    ),
    369 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6c70a40040e8712605f3958bd6b68d56',
      'native_key' => 'resource_tree_node_tooltip',
      'filename' => 'modSystemSetting/b177b041d77878fade540c1456a3b4de.vehicle',
    ),
    370 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7aa6977ee6a00b0c231c7de776232a00',
      'native_key' => 'richtext_default',
      'filename' => 'modSystemSetting/b8f5769bfc79227406411dfa29f223a4.vehicle',
    ),
    371 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7ee080292f36f41309a0675db0342879',
      'native_key' => 'search_default',
      'filename' => 'modSystemSetting/7587385c50c566a41f65c63f15496686.vehicle',
    ),
    372 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2ad80a47731ad4ba8b8f2b21e751f47f',
      'native_key' => 'server_offset_time',
      'filename' => 'modSystemSetting/f9fc142c5d1940a96cff1877fd2326ce.vehicle',
    ),
    373 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6236c07ba53885ef6bdfd63f68cf37ba',
      'native_key' => 'server_protocol',
      'filename' => 'modSystemSetting/4f16daf512fba2872e98238cbf9b448a.vehicle',
    ),
    374 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7627d5904b3f7ec48afe51df9c24dec4',
      'native_key' => 'session_cookie_domain',
      'filename' => 'modSystemSetting/e8fa2ee0c6e09fd00f0dc85868c479ff.vehicle',
    ),
    375 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '55c59beae06e60ad6a463ce9b1627966',
      'native_key' => 'default_username',
      'filename' => 'modSystemSetting/9a25a6dd10e14031e393616bdf2f2f9a.vehicle',
    ),
    376 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7a864254a275ab6d09df4e74e23d2e64',
      'native_key' => 'session_cookie_lifetime',
      'filename' => 'modSystemSetting/8f24ee350502cad2ffb7beaafaaf4625.vehicle',
    ),
    377 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '03fe636b1d7b7ddbacf09aa8e0ef3a7f',
      'native_key' => 'session_cookie_path',
      'filename' => 'modSystemSetting/d83d326111169599aa773ea3cd103217.vehicle',
    ),
    378 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '54b98341997a3d1af9870e78cc32ca30',
      'native_key' => 'session_cookie_secure',
      'filename' => 'modSystemSetting/aa4b50155d526adbd5b9ada9f6fff92c.vehicle',
    ),
    379 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a21dd92f6df31cbedde53ac9724295c3',
      'native_key' => 'session_cookie_httponly',
      'filename' => 'modSystemSetting/88fa069c7f693bfc4eaa617ad44059ad.vehicle',
    ),
    380 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b0fa5094fd209e208ab8c0d6be2c952b',
      'native_key' => 'session_gc_maxlifetime',
      'filename' => 'modSystemSetting/71c4349bc65534612cc1d4a21f3bab06.vehicle',
    ),
    381 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0a44d990b39b6bac255725694ebabe31',
      'native_key' => 'session_handler_class',
      'filename' => 'modSystemSetting/c590c94eddb8282b1b586a2614d2c823.vehicle',
    ),
    382 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '249513d5ca4e49d8b13cf53d6087f02c',
      'native_key' => 'session_name',
      'filename' => 'modSystemSetting/9a7225abf343be153dbcc02b0dc8d307.vehicle',
    ),
    383 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6635c94389d1a22aa823deb182217e8b',
      'native_key' => 'set_header',
      'filename' => 'modSystemSetting/9024ca6b4b38bdd47ffb12439d1ebd8a.vehicle',
    ),
    384 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '53bc3cff4c03de799c26f2c6bd260b8c',
      'native_key' => 'show_tv_categories_header',
      'filename' => 'modSystemSetting/805a04097b95ce7636e7915904c6c251.vehicle',
    ),
    385 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3ba31eb84fb1858e9792a07dcf3c27c9',
      'native_key' => 'signupemail_message',
      'filename' => 'modSystemSetting/4028e874b739f3548159f180cac582e0.vehicle',
    ),
    386 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1eedffedb7d8d35df41cf88c44cd772c',
      'native_key' => 'site_name',
      'filename' => 'modSystemSetting/d2c81dc3e40ba1231a0bace00fb4d71e.vehicle',
    ),
    387 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9c5249c3db7d0171c94b493231cbee94',
      'native_key' => 'site_start',
      'filename' => 'modSystemSetting/d8276c195ebc17e4027cb633e5bfd42a.vehicle',
    ),
    388 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '96aef8c7278870832cad89bf8ed27326',
      'native_key' => 'site_status',
      'filename' => 'modSystemSetting/711ce40be33d16d3d75b005801d83ef9.vehicle',
    ),
    389 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '15a9dd971013a39bdc52a23ad79e2db4',
      'native_key' => 'site_unavailable_message',
      'filename' => 'modSystemSetting/d006f23705fbe415f29748c936706f79.vehicle',
    ),
    390 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b3813cf0ddbbc8b1ccdb6f5a978a92da',
      'native_key' => 'site_unavailable_page',
      'filename' => 'modSystemSetting/821b017ada9116191149817f6193f47a.vehicle',
    ),
    391 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9a6d193637816cd8778157fff45d40dd',
      'native_key' => 'strip_image_paths',
      'filename' => 'modSystemSetting/f71828585d3b8240daecb3119893a629.vehicle',
    ),
    392 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '193b76f46ef1e5c9da29a599f4f43ef8',
      'native_key' => 'symlink_merge_fields',
      'filename' => 'modSystemSetting/b1a6610a83458feb18aa4e3b246ea07f.vehicle',
    ),
    393 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '234672e4576b2041e0670f6b2426f51c',
      'native_key' => 'syncsite_default',
      'filename' => 'modSystemSetting/6a31e76aa60313cf56b7668dfc38f0cf.vehicle',
    ),
    394 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b70d37bece454e8318248bfb025e0b4c',
      'native_key' => 'topmenu_show_descriptions',
      'filename' => 'modSystemSetting/e37cc04463385a08a0ff93c23555e44f.vehicle',
    ),
    395 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3c06aa0fcf5ec54a6d8aa30b21b357b6',
      'native_key' => 'tree_default_sort',
      'filename' => 'modSystemSetting/e11a2133b0d2697aa2f5e7f73bdcac3e.vehicle',
    ),
    396 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aa4c7ee3da6309ed146735043bc6effd',
      'native_key' => 'tree_root_id',
      'filename' => 'modSystemSetting/b0c7c4cc636d4f5a08623be4c351ed9c.vehicle',
    ),
    397 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '231453d7c9fa1c3e756ad40b7166b51a',
      'native_key' => 'tvs_below_content',
      'filename' => 'modSystemSetting/f68b85c785ea839604963d7b51f28738.vehicle',
    ),
    398 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c1bd52ab7c62c6543c2207ca2ac5b863',
      'native_key' => 'udperms_allowroot',
      'filename' => 'modSystemSetting/070000242c1f4cd118c9191c504d043f.vehicle',
    ),
    399 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'baed7d8e29c94ac10f9b36e63186437d',
      'native_key' => 'unauthorized_page',
      'filename' => 'modSystemSetting/4a726600aa38644f8e1b745002700821.vehicle',
    ),
    400 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c53cf6efcb99913fc920b8a0d26a36b1',
      'native_key' => 'upload_files',
      'filename' => 'modSystemSetting/b4d73f6c887ffe3129f9053d3383b7ba.vehicle',
    ),
    401 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bb5854b22c153996ba2d85b6e079f31c',
      'native_key' => 'upload_flash',
      'filename' => 'modSystemSetting/cc5f33a64f5a6b195fe71c76f50937d7.vehicle',
    ),
    402 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd5f5d12bc1eb3221660f05bc9b860ca4',
      'native_key' => 'upload_images',
      'filename' => 'modSystemSetting/d343f92270bbe9ed2e5386e4a1b57ad8.vehicle',
    ),
    403 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e9350d6c3c79992a9fe85b95a46ffaa7',
      'native_key' => 'upload_maxsize',
      'filename' => 'modSystemSetting/951be32c5a2128cc407ec8fc478c74b9.vehicle',
    ),
    404 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c91706326fcc8a46dbe23a7430f21a4e',
      'native_key' => 'upload_media',
      'filename' => 'modSystemSetting/5a14d84c825d5bfe5fbe7a785b09dc9f.vehicle',
    ),
    405 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5c919d083cb90e22bd10f876f30454d8',
      'native_key' => 'use_alias_path',
      'filename' => 'modSystemSetting/f9f03941212ae7ac1680d9bf679fb115.vehicle',
    ),
    406 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dd4c4e9564dd55823d81b3c913d20ac1',
      'native_key' => 'use_browser',
      'filename' => 'modSystemSetting/5f239a44fee0e0bd846988294b0837c3.vehicle',
    ),
    407 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6fe9a87d0f5f533a1bc37a5eb5bc8a5f',
      'native_key' => 'use_editor',
      'filename' => 'modSystemSetting/6e9b6ac0c45c7ae8fd6b11f6209e6d68.vehicle',
    ),
    408 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '78f86375f316bca2ab0e3cb3366ff741',
      'native_key' => 'use_multibyte',
      'filename' => 'modSystemSetting/35cd6adffbf111ed4a926fd40b79e6cf.vehicle',
    ),
    409 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7770f8e17a4751a29ff8545d7cda81b5',
      'native_key' => 'use_weblink_target',
      'filename' => 'modSystemSetting/a4a9abff56f8485db4391125e7607e9b.vehicle',
    ),
    410 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd0ba741246e5e6d7a14cea4e04652004',
      'native_key' => 'webpwdreminder_message',
      'filename' => 'modSystemSetting/b00f42ef0c0c81697b62b79089d860b2.vehicle',
    ),
    411 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '03340edfb7dd2b6560e84a686e326a4c',
      'native_key' => 'websignupemail_message',
      'filename' => 'modSystemSetting/3c7ff04fb92a23ca895f084e36e51984.vehicle',
    ),
    412 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '556d6bcf2f25c4a4c284b73fc7ff4abd',
      'native_key' => 'welcome_screen',
      'filename' => 'modSystemSetting/5975b687ab94c1de3422c262e8be27d3.vehicle',
    ),
    413 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5fc6d66e2b5226c7b363207d3f81be64',
      'native_key' => 'welcome_screen_url',
      'filename' => 'modSystemSetting/ba7e9a3acfde2e442d3e3d49a9aac6ff.vehicle',
    ),
    414 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5e05d4f75fee4fcf5a5be353650e82b0',
      'native_key' => 'welcome_action',
      'filename' => 'modSystemSetting/682a4d5b1258fabf82be8621332d620d.vehicle',
    ),
    415 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1ad251acfbb29b891116c13311bd69ac',
      'native_key' => 'welcome_namespace',
      'filename' => 'modSystemSetting/46d127c02accd843f2ae86e908a0014d.vehicle',
    ),
    416 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '934f82eaccc93289081d49b4b39aa1f5',
      'native_key' => 'which_editor',
      'filename' => 'modSystemSetting/3984e3bda9aabc7a340ce0027f4837ae.vehicle',
    ),
    417 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd680a54f420d2e51f6091ba81dec19d3',
      'native_key' => 'which_element_editor',
      'filename' => 'modSystemSetting/3f3e5aef3ada56e92613e4280d73e48e.vehicle',
    ),
    418 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b1733bf7d42eedd90abd1acea80b012f',
      'native_key' => 'xhtml_urls',
      'filename' => 'modSystemSetting/56efe7b1962ca5c8fc988f7728862d15.vehicle',
    ),
    419 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '18b05bf86ce2026c8d8dec4b204a8316',
      'native_key' => 'enable_gravatar',
      'filename' => 'modSystemSetting/f0f8b6e0fea03c1a974df2b207f5c45a.vehicle',
    ),
    420 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7f06409303d205e46f8719a784a8d9c0',
      'native_key' => 'mgr_tree_icon_context',
      'filename' => 'modSystemSetting/0b2b62809012a2731906f23c66013ccc.vehicle',
    ),
    421 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c42bd619e65dfb755624dcd9f8686099',
      'native_key' => 'mgr_source_icon',
      'filename' => 'modSystemSetting/b3764d5a74c291af803187c4c801d644.vehicle',
    ),
    422 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bf472d8e468e490e6f03781106df3bef',
      'native_key' => 'main_nav_parent',
      'filename' => 'modSystemSetting/bb768987b0185d66e7e9c782b997d4ca.vehicle',
    ),
    423 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '769e60e55ea2d5605c98f61f66430175',
      'native_key' => 'user_nav_parent',
      'filename' => 'modSystemSetting/13c456a715c41a68b1930837296f9646.vehicle',
    ),
    424 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fb804c007890c56d07957f9f45c25608',
      'native_key' => 'auto_isfolder',
      'filename' => 'modSystemSetting/9c506668d461ae72f6633aaa916923d1.vehicle',
    ),
    425 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0e91c49cb6ee908b70d22b9aa5314cbc',
      'native_key' => 'manager_use_fullname',
      'filename' => 'modSystemSetting/5abcb6662077e97f8fd8fb00551eee37.vehicle',
    ),
    426 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => 'e66b188e97d791170fe1bba655182b72',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'allow_tags_in_post',
      ),
      'filename' => 'modContextSetting/1848c5fce664f8dea05e88d52185b995.vehicle',
    ),
    427 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '3d3248c2c6766eddeb00dab8bac8cc45',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'modRequest.class',
      ),
      'filename' => 'modContextSetting/c5cadf605b5ec5056d94a48c8f63d0ba.vehicle',
    ),
    428 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => 'db353dd2a40edb265a2ff2e5818ef3ed',
      'native_key' => 1,
      'filename' => 'modUserGroup/d2d860be7d204177222442284f77ec0e.vehicle',
    ),
    429 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboard',
      'guid' => '2d60a8d8a4edbe62984c6db7af5d325f',
      'native_key' => 1,
      'filename' => 'modDashboard/c63c5a4b9f84c834975f196b202f3dd4.vehicle',
    ),
    430 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMediaSource',
      'guid' => 'bd28456f608692b60fd77d4ef7c448c2',
      'native_key' => 1,
      'filename' => 'modMediaSource/431321d57d9bbd7858598dd45214f3fa.vehicle',
    ),
    431 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '7d1843e4a96d04905b530900c6639b39',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/882c13b68f888196a4b21848f17cc1d6.vehicle',
    ),
    432 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'dc5a99273980692637165319873bce8b',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/6639ff2422cc65b6572bac468401aeb5.vehicle',
    ),
    433 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '20546037433f35f831c7419f1e2c37b4',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/10ae5eebf1c4e28baf5244cffa1e4e5f.vehicle',
    ),
    434 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '22198ad305a0d4db9234958e6762f644',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/ce3d9551e9101be50298cd9f88b886be.vehicle',
    ),
    435 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '417b4bece01e6ed143715fa85db7d338',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/3c0176da349638b72c553798933b081e.vehicle',
    ),
    436 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => '996fe5eaf973a40245e5e21b8e0d7ae5',
      'native_key' => 1,
      'filename' => 'modUserGroupRole/34657b9f17c9fb32c652d4d4e85be65d.vehicle',
    ),
    437 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => '1c960ed480f811ddfe26f7b1d7a3a479',
      'native_key' => 2,
      'filename' => 'modUserGroupRole/a3e382f509fff1f73c248aff970f0c0d.vehicle',
    ),
    438 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '7e9f182faba04ca887ac8493c780fb3e',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/f21a72a8c7aa6fa51d82fab5313b11fe.vehicle',
    ),
    439 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '3b692ae72319bb8e0897b92e55e262f9',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/416efd81200045d0f1ce8aa72c2466ac.vehicle',
    ),
    440 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '74d555f92692271846e94f630cef5511',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/cfbc3989a7e0cd6d2d799372b51dd7c2.vehicle',
    ),
    441 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '39c6af02b5fb71e3cf588e440d0b62b3',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/c47b885bf645ce1bd6cd8d3b14eccf17.vehicle',
    ),
    442 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '823dbf988477a6700a6bf9655fdd9fb9',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/7e59cb8e0a2a5a27dcdbec505b19d25c.vehicle',
    ),
    443 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '799bbc8752f4ad0a399c8a2528cffda1',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/961c08db6d985cec273587edebacdfdf.vehicle',
    ),
    444 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'd23d1d3bd12804a20e91d63d38dbd754',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/b76af1fdb1938991b4c79cb48fa0f230.vehicle',
    ),
    445 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'c86c8835ec5b03348781d7b847dc138b',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/285c9eed60e319325e590d323bbb2a4f.vehicle',
    ),
    446 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'c829fc6a3eeb156413af8e846e06e666',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/6ed8e24eb41fd74cfccc6843bb79a09f.vehicle',
    ),
    447 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '14e0535fc8173fdc49f9809c468b851b',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/1a9a2b018528c348a3d95303ea56f773.vehicle',
    ),
    448 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '9f904c653746ffeb988f95a900367ad3',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/1e6c0a8d8bd0f4e24c24e725312b4b1f.vehicle',
    ),
    449 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '60dcf32439a02f885826315a1f87e100',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/aaea9784cd00c9aaedea55cda8a59546.vehicle',
    ),
    450 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '6d4550388d2ff3e1383cd661c020d539',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/f2b7c79cbbb37e097bd5e2f8763d45a2.vehicle',
    ),
    451 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '25306bc77a92f2cb9a4875de2840643b',
      'native_key' => 1,
      'filename' => 'modAccessPolicy/d19f9db152445f0c3aa898c5ccc8c13a.vehicle',
    ),
    452 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '5f69560c03a482c8c551c38b00dcf6ce',
      'native_key' => 2,
      'filename' => 'modAccessPolicy/8c5be3a8a9fe982853176446da229bdc.vehicle',
    ),
    453 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '0096e1ce7acfa4c324d46f4081c7f4b2',
      'native_key' => 3,
      'filename' => 'modAccessPolicy/dbb8323acccf8218d0e5a7f7efe3008a.vehicle',
    ),
    454 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '3b34812e4e02100250b1c1e02cfcc8d2',
      'native_key' => 4,
      'filename' => 'modAccessPolicy/2986448d7818bd54ef11ea96f8cd508d.vehicle',
    ),
    455 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '91f82338abdccf7671b673f3b26830a2',
      'native_key' => 5,
      'filename' => 'modAccessPolicy/e993e73747972c0e3bebc7d58802a2a5.vehicle',
    ),
    456 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '3d8fa086c815357fb83965c3ab077141',
      'native_key' => 6,
      'filename' => 'modAccessPolicy/bb29132bbbfedda29b3ccbe49eadf6fc.vehicle',
    ),
    457 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '1459866f375ef3683790a192e8c5abcc',
      'native_key' => 7,
      'filename' => 'modAccessPolicy/4534dadf6590cdca0ff4641fd63c5e2b.vehicle',
    ),
    458 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '78bd6ee2311c0f0d30da35f9dc700846',
      'native_key' => 8,
      'filename' => 'modAccessPolicy/3a262a792519e631c09cdbb0b925a99b.vehicle',
    ),
    459 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '7e45c51f4c4d6e7f8eb0b4fb599a87aa',
      'native_key' => 9,
      'filename' => 'modAccessPolicy/3f939cd84ad9b43f2ac4b0ec790644c6.vehicle',
    ),
    460 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'e4856c86d9548134d2b8833a00ba9f8a',
      'native_key' => 10,
      'filename' => 'modAccessPolicy/d4a16bcaa4f20b62fdcf722ca63be378.vehicle',
    ),
    461 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'a8c8494e61caca12a26e8dfbbe354597',
      'native_key' => 11,
      'filename' => 'modAccessPolicy/09f6b036c4eba365f415ede5fe9c1b88.vehicle',
    ),
    462 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '5e74a48eddd39cd87b7d5482457b4a7f',
      'native_key' => 12,
      'filename' => 'modAccessPolicy/63d5113ee9facf961046cf5d6efbb98b.vehicle',
    ),
    463 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => '8605eb5b2439dfe8747ba4046d634e7c',
      'native_key' => 'web',
      'filename' => 'modContext/daaf224e93519d2a7ab7eb7044c24520.vehicle',
    ),
    464 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => 'd52a03505496e9f3c5f175ae37abb68b',
      'native_key' => 'mgr',
      'filename' => 'modContext/7a6d878454764053a08ae73e7899fd47.vehicle',
    ),
    465 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'a4a9a40a930799bf3c2fe446b8d64b42',
      'native_key' => 'a4a9a40a930799bf3c2fe446b8d64b42',
      'filename' => 'xPDOFileVehicle/43658885512c425e7a878ce0fbeda2ba.vehicle',
    ),
    466 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'd66616a0605cda60603a2c770bce0e70',
      'native_key' => 'd66616a0605cda60603a2c770bce0e70',
      'filename' => 'xPDOFileVehicle/c86940a213053dc941cd7508ad1372df.vehicle',
    ),
    467 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'bb7017d2b7396f37df4783ffc4cd5cd7',
      'native_key' => 'bb7017d2b7396f37df4783ffc4cd5cd7',
      'filename' => 'xPDOFileVehicle/1c0f6d39c62bfbd91919e20d8eb5366e.vehicle',
    ),
    468 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '88b237ab68dd5be57dcd4a507b867209',
      'native_key' => '88b237ab68dd5be57dcd4a507b867209',
      'filename' => 'xPDOFileVehicle/6f7e4f39b9b276f7be62dc56b3fb5192.vehicle',
    ),
  ),
);